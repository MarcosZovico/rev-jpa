package com.atomsail.atombi.data.etl.cipher;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

@Component
public class AtomCipherImpl implements AtomCipher,InitializingBean {

    public static final String CHARSET_NAME = "UTF-8";
    private static final Logger LOGGER = LoggerFactory.getLogger(AtomCipherImpl.class);
    private static final String ALGORITHM = "AES";
    /**
     * tipo do algoritmo da cifra
     */
    private static final String CIPHER_ALGORITHM = "AES/CBC/PKCS5Padding";
    private static Base64 base64 = new Base64(true);
    private final SecretKey key;

    @Value("${atombi.crypto.salt}")
    private String salt;

    public AtomCipherImpl(@Value("${atombi.crypto.default_key}") String publicKey) throws CreateCipherException {
        try {

            byte[] encodedPrivateBytes = Hex.decodeHex(decodeBase64(publicKey).toCharArray());
            key = new SecretKeySpec(encodedPrivateBytes, ALGORITHM);
        } catch (DecoderException e) {
            LOGGER.error(e.getMessage(), e);
            throw new CreateCipherException(e);
        }
    }

    public static String encodeBase64(String msg) throws CreateCipherException {
        try {
            return new String(base64.encode(msg.getBytes(CHARSET_NAME)));
        } catch (UnsupportedEncodingException e) {
            throw new CreateCipherException(e);
        }
    }

    /**
     * Descriptografa um texto
     *
     * @param msg texto condificado em base64
     * @return
     */
    public static String decodeBase64(String msg) throws CreateCipherException {

        try {
            return new String(base64.decode(msg.getBytes(CHARSET_NAME)));
        } catch (UnsupportedEncodingException e) {
            throw new CreateCipherException(e);
        }
    }

    @Override
    public String encrypt(String msg) throws CreateCipherException {

        String plainText = encodeBase64(msg);

        try {
            IvParameterSpec ivParameterSpec = new IvParameterSpec(salt.getBytes());
            Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, key, ivParameterSpec);
            byte[] bts = plainText.getBytes(CHARSET_NAME);
            byte[] encrypted = cipher.doFinal(bts);
            char[] encryptedTranspherable = Hex.encodeHex(encrypted);

            return Base64.encodeBase64URLSafeString(new String(encryptedTranspherable).getBytes());

        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            throw new CreateCipherException(e);
        }
    }

    @Override
    public String decrypt(String encryptedText) throws CreateCipherException {

        try {
            IvParameterSpec ivParameterSpec = new IvParameterSpec(salt.getBytes());
            Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, key, ivParameterSpec);

            byte[] bts = Hex.decodeHex(decodeBase64(encryptedText).toCharArray());
            byte[] descripted = cipher.doFinal(bts);

            return decodeBase64(new String(descripted));

        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            throw new CreateCipherException(e);
        }
    }

    @Override
    public String getKeyAsString() {
        String hash = new String(Hex.encodeHex(key.getEncoded()));
        return Base64.encodeBase64URLSafeString(hash.getBytes());
    }

    @Override
    public Key getKey() {
        return key;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(salt, "salt must be set");
    }
}
