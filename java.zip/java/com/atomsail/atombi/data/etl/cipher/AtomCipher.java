package com.atomsail.atombi.data.etl.cipher;


import java.security.Key;

/**
 * interface AtomCipher onde contem os metodos criptografar e descriptografar
 *
 * @author Rafael Kiyota
 * @version 1.0
 * @created 17/04/2013
 */
public interface AtomCipher {

    /**
     * criptografa um texto
     *
     * @param plainText texto original
     * @return texto criptografado
     * @throws CreateCipherException caso nao consiga criptografar
     */
    String encrypt(String plainText) throws CreateCipherException;

    /**
     * descriptografa um texto
     *
     * @param encryptedText texto criptografado
     * @return o texto original descriptografado
     * @throws CreateCipherException caso nao consiga criptografar
     */
    String decrypt(String encryptedText) throws CreateCipherException;

    String getKeyAsString();

    Key getKey();
}