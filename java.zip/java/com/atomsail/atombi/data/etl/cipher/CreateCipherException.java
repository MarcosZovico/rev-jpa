package com.atomsail.atombi.data.etl.cipher;

/**
 * excecao e jogado quando ocorre algum erro na implementacao da cifra
 *
 * @author Rafael Kiyota
 * @version 1.0
 * @created 17/04/2013
 */
public class CreateCipherException extends Exception {

    public CreateCipherException() {
    }

    public CreateCipherException(String message) {
        super(message);
    }

    public CreateCipherException(String message, Throwable cause) {
        super(message, cause);
    }

    public CreateCipherException(Throwable cause) {
        super(cause);
    }

    public CreateCipherException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}