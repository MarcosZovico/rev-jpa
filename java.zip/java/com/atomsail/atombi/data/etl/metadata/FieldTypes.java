package com.atomsail.atombi.data.etl.metadata;

public class FieldTypes {
    public static final String TEXT = "TEXT";
    public static final String NUMBER = "NUMBER";
    public static final String DATE = "DATE";
}
