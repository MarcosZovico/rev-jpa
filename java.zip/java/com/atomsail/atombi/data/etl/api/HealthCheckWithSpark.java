package com.atomsail.atombi.data.etl.api;

import org.apache.spark.SparkStatusTracker;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HealthCheckWithSpark {

    @Autowired
    private SparkSession sparkSession;

    @GetMapping("/health-spark")
    public SparkStatusTracker check() {
        return sparkSession.sparkContext().statusTracker();
    }
}
