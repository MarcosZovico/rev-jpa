package com.atomsail.atombi.data.etl.api;

import com.atomsail.atombi.data.etl.dto.AtomdbDataDTO;
import com.atomsail.atombi.data.etl.jobs.star.csv.jobs.StarSchemaInsertCsvJob;
import com.sun.management.OperatingSystemMXBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.management.MBeanServerConnection;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.util.UUID;

@RestController
@RequestMapping("/api/v2")
public class ProcessStarSchemaCsvApi {

    private static final Logger log = LoggerFactory.getLogger(StarSchemaInsertCsvJob.class);

    protected JobLauncher jobLauncher;

    @Autowired
    private JobRegistry jobRegistry;

    @PutMapping("/etl/star/csv")
    public ResponseEntity<String> processStarSchemaCsv(@RequestBody AtomdbDataDTO atomdbData) throws IOException {

        log.info("iniciado processo de carga para {}", atomdbData);

        Long availableMemory = getAvailableMemory();
        Double cpuUsage = getCpuUsage();

        if (cpuUsage > .6) {
            System.out.println("ALERTA - cpu load: " + cpuUsage);
        }

        System.out.println("memory available: " + (availableMemory / (1024 * 1024)));
        if (availableMemory < getMemoryThreshould()) {
            System.out.println("ALERTA - memory available: " + availableMemory);
        }

        // adiciona os parametros para execucao do job
        JobParameters jobParameters = new JobParametersBuilder()
                .addLong("accountId", atomdbData.getAccountId())
                .addLong("atomdbActionId", atomdbData.getActionId())
                .addLong("atomdbDataId", atomdbData.getCubeDataId())
                .addLong("atomdbId", atomdbData.getCubeId())
                .addLong("userId", atomdbData.getUserId())
                .addString("uuid", UUID.randomUUID().toString())
                .toJobParameters();

        try {

            // procura o job no repostiorio
            Job job = jobRegistry.getJob(StarSchemaInsertCsvJob.PROCESS_STAR_SCHEMA_CSV_JOB);
            if (job == null) {
                throw new NoSuchJobException("Job " + StarSchemaInsertCsvJob.PROCESS_STAR_SCHEMA_CSV_JOB + " nao encontrado");
            }

            // executa o job
            JobExecution execution = jobLauncher.run(jobRegistry.getJob(StarSchemaInsertCsvJob.PROCESS_STAR_SCHEMA_CSV_JOB), jobParameters);
            log.info("Execucao iniciada para {}", execution);

            return ResponseEntity.accepted().build();

        } catch (JobExecutionAlreadyRunningException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (JobRestartException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (JobInstanceAlreadyCompleteException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (JobParametersInvalidException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (NoSuchJobException e) {
            return ResponseEntity.notFound().build();
        }


    }


    private long getAvailableMemory() {
        return Runtime.getRuntime().maxMemory() - Runtime.getRuntime().freeMemory();
    }

    private double getMemoryThreshould() {
        System.out.println("maxMemory: " + Runtime.getRuntime().maxMemory() / (1024 * 1024));
        System.out.println("totalMemory: " + Runtime.getRuntime().totalMemory() / (1024 * 1024));
        return Runtime.getRuntime().maxMemory() * .2;
    }

    private double getCpuUsage() throws IOException {
        MBeanServerConnection mbsc = ManagementFactory.getPlatformMBeanServer();
        OperatingSystemMXBean osMBean = ManagementFactory.newPlatformMXBeanProxy(
                mbsc, ManagementFactory.OPERATING_SYSTEM_MXBEAN_NAME, OperatingSystemMXBean.class);

        return osMBean.getProcessCpuLoad();
    }

    @Autowired
    public ProcessStarSchemaCsvApi(@Qualifier("asyncJobRunner") JobLauncher jobLauncher) {
        this.jobLauncher = jobLauncher;
    }

}
