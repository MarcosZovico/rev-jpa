package com.atomsail.atombi.data.etl.api;

import com.atomsail.atombi.data.etl.dto.AtomdbExportDataDTO;
import com.atomsail.atombi.data.etl.jobs.star.csv.jobs.StarSchemaInsertCsvJob;
import com.sun.management.OperatingSystemMXBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.management.MBeanServerConnection;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.util.UUID;

import static com.atomsail.atombi.data.etl.jobs.export.ExportDataCsvJob.EXPORT_DATA_CSV_JOB;

@RestController
@RequestMapping("/api/v2")
public class ExportDataCsvApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(StarSchemaInsertCsvJob.class);

    protected JobLauncher jobLauncher;

    @Autowired
    private JobRegistry jobRegistry;

    @PutMapping("/etl/export/csv")
    public ResponseEntity<String> processStarSchemaCsv(@RequestBody AtomdbExportDataDTO exportData) throws IOException {

        LOGGER.info("iniciado processo de exportar dados para {}", exportData);

        if (LOGGER.isDebugEnabled()){
            showSystemInfo();
        }

        // adiciona os parametros para execucao do job
        JobParameters jobParameters = new JobParametersBuilder()
                .addString("dto", exportData.toJson())
                .addString("uuid", UUID.randomUUID().toString())
                .toJobParameters();
        try {

            // procura o job no repostiorio
            Job job = jobRegistry.getJob(EXPORT_DATA_CSV_JOB);
            if (job == null) {
                throw new NoSuchJobException("Job " + EXPORT_DATA_CSV_JOB + " nao encontrado");
            }

            // executa o job
            JobExecution execution = jobLauncher.run(jobRegistry.getJob(EXPORT_DATA_CSV_JOB), jobParameters);
            LOGGER.info("Execucao iniciada para {}", execution);

            return ResponseEntity.accepted().build();

        } catch (JobExecutionAlreadyRunningException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (JobRestartException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (JobInstanceAlreadyCompleteException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (JobParametersInvalidException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (NoSuchJobException e) {
            return ResponseEntity.notFound().build();
        }

    }

    @Autowired
    public ExportDataCsvApi(@Qualifier("asyncJobRunner") JobLauncher jobLauncher) {
        this.jobLauncher = jobLauncher;
    }

    private void showSystemInfo() throws IOException {

        Long availableMemory = getAvailableMemory();
        Double cpuUsage = getCpuUsage();

        if (cpuUsage > .6) {
            LOGGER.debug("ALERTA - cpu load: " + cpuUsage);
        }

        LOGGER.debug("memory available: " + (availableMemory / (1024 * 1024)));

        if (availableMemory < getMemoryThreshould()) {
            LOGGER.debug("ALERTA - memory available: " + availableMemory);
        }
    }

    private long getAvailableMemory() {
        return Runtime.getRuntime().maxMemory() - Runtime.getRuntime().freeMemory();
    }

    private double getMemoryThreshould() {
        LOGGER.debug("maxMemory: " + Runtime.getRuntime().maxMemory() / (1024 * 1024));
        LOGGER.debug("totalMemory: " + Runtime.getRuntime().totalMemory() / (1024 * 1024));
        return Runtime.getRuntime().maxMemory() * .2;
    }

    private double getCpuUsage() throws IOException {
        MBeanServerConnection mbsc = ManagementFactory.getPlatformMBeanServer();
        OperatingSystemMXBean osMBean = ManagementFactory.newPlatformMXBeanProxy(
                mbsc, ManagementFactory.OPERATING_SYSTEM_MXBEAN_NAME, OperatingSystemMXBean.class);

        return osMBean.getProcessCpuLoad();
    }


}
