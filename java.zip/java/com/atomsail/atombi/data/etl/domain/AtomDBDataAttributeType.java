package com.atomsail.atombi.data.etl.domain;

/**
 * @author Marcos Souza
 * @version 1.0
 * @created 19-abr-2016 13:44:08
 */
public enum AtomDBDataAttributeType {
	/**
	 * Numero total de linhas
	 */
	TOTAL_ROWS,
	/**
	 * Tamanho do arquivo
	 */
	SIZE,
	/**
	 * Nome original do arquivo
	 */
	FILENAME,
	/**
	 * Url do arquivo que o usuário fez upload, armazenado no repositório S3.
	 */
	S3_URL,
	/**
	 * Url do arquivo transformado no repositório S3. Arquivo para popular a
	 * fact table, time dimensions e dimensions no star schema. Armazena todas
	 * as urls referente a uma carga de dados;
	 */
	S3_DONE_URL,

	/**
	 * Delimitador do arquivo
	 */
	DELIMITER,
	/**
	 * json com a formatacao de entrada de cada campo
	 * <code>List&#x3C;DatasourceFieldVO&#x3E;</code>
	 */
	FIELD_INPUT_MAP,
	/**
	 * Verifica se o arquivo possui header
	 */
	HAS_HEADER,
	/**
	 * Mapeamento das ordens dos campos do arquivo com a estrutura do banco.
	 */
	FROM_TO_MAP,
	/**
	 * Referencia do aquivo armazendo na amazon
	 */
	ENTRY_UUID,
	/**
	 * Código defenido pelo usuário que servirá para remoção, ou adição de dados
	 * na base analitica.
	 */
	REF_CODE,
	/**
	 * Usuário que criou ou adicionou dados, obs: armazenado somente o id do
	 * usuário.
	 */
	OWNER,
	/**
	 * Mensagen de erro durante o processo de carga
	 */
	DATALOAD_ERROR,
	/**
	 * Transformação ETL configurada em formato xml
	 */
	ETL_TRANS,
	/**
	 * Armazena os erros (StackTrace) durante o processo de carga.
	 */
	INTERNAL_ERROR,

	/**
	 * Tempo de criacao da base de dados analitica do cubo no monetdb
	 */
	STATUS_CREATING_ANALYTIC_DB,
	/**
	 * Tempo decriacao do schema do mondrian para o cubo
	 */
	STATUS_CREATING_MONDRIAN_SCHEMA,

	/**
	 * Tempo de criacao da transformação ETL
	 */
	STATUS_CREATING_ETL_TRANS,

	/**
	 * Tempo de Execução da transformação ETL
	 */
	STATUS_RUNNING_ETL_TRANS,

	/**
	 * Tempo aguandando para executar transformação ETL
	 */
    STATUS_WAITING_RUN_ETL,

    /**
     * Tempo aguandando para popular os dados no banco
     */
    STATUS_WAITING_FACT_LOAD,


    /**
	 * Tempo para popular os dados no banco
	 */
	STATUS_FACT_LOAD,

    /**
     * Finalizado o processo de carga
     */
    STATUS_COMPLETED,

	/**
	 * Erro o processo de carga
	 */
	STATUS_ERROR,

	STATUS_UPDATING_DIMENSION
}