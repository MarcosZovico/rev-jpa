package com.atomsail.atombi.data.etl.domain;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "datasource_data")
public class AtomDBData {

    @Id
    @GenericGenerator(
            name = "DATASOURCE_DATA_DATASOURCEDATAID_GENERATOR",
            strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
            parameters = {
                    @Parameter(name = "sequence_name", value = "DATASOURCE_DATA_DATASOURCE_DATA_ID_SEQ"),
                    @Parameter(name = "initial_value", value = "1"),
                    @Parameter(name = "increment_size", value = "1")
            }
    )
    @GeneratedValue(generator = "DATASOURCE_DATA_DATASOURCEDATAID_GENERATOR")
    @Column(name = "datasource_data_id", nullable = false)
    private Long dataId;

    @Column(name = "datasource_data_created", nullable = false)
    private Date created;

    @Column(name = "datasource_data_updated", nullable = false)
    private Date updated;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "datasource_id", nullable = false)
    private AtomDB atomDB;

    @Enumerated(EnumType.STRING)
    @Column(name = "datasource_data_status_id", nullable = false)
    private AtomDBDataStatus status;

    @Column(name = "datasource_input_type_id", nullable = false)
    private String type;


    public AtomDBData() {
    }

    public Long getDataId() {
        return dataId;
    }

    public void setDataId(Long dataId) {
        this.dataId = dataId;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public AtomDB getAtomDB() {
        return atomDB;
    }

    public void setAtomDB(AtomDB atomDB) {
        this.atomDB = atomDB;
    }

    public AtomDBDataStatus getStatus() {
        return status;
    }

    public void setStatus(AtomDBDataStatus status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "AtomDBData{" +
                "dataId=" + dataId +
                ", status=" + status +
                ", type='" + type + '\'' +
                ", updated=" + updated +
                '}';
    }
}
