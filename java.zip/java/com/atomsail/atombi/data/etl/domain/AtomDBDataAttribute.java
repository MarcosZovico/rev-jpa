package com.atomsail.atombi.data.etl.domain;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Date;

/**
 * The persistent class for the datasource_data_attribute database table.
 */
@Entity
@Table(name = "datasource_data_attribute")
public class AtomDBDataAttribute {

    @EmbeddedId
    private AtomDBDataAttributePK id;

    @Column(name = "datasource_data_attribute_created", nullable = false)
    private Date created;

    @Column(name = "datasource_data_attribute_metadata", nullable = false, length = 32)
    private String metadata;

    @Column(name = "datasource_data_attribute_updated", nullable = false)
    private Date updated;

    @Lob
    @Type(type = "text")
    @Column(name = "datasource_data_attribute_value", nullable = false)
    private String value;

    public AtomDBDataAttribute() {

    }

    public AtomDBDataAttributePK getId() {
        return id;
    }

    public void setId(AtomDBDataAttributePK id) {
        this.id = id;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getMetadata() {
        return metadata;
    }

    public void setMetadata(String metadata) {
        this.metadata = metadata;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "AtomDBDataAttribute{" +
                "id=" + id +
                ", metadata='" + metadata + '\'' +
                ", value='" + value + '\'' +
                '}';
    }
}