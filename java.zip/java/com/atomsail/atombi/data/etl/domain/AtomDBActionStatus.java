package com.atomsail.atombi.data.etl.domain;

/**
 * Created by msouza on 13/07/17.
 */
public enum AtomDBActionStatus {
    WAITING,
    RUNNING,
    TIME_OUT,
    ERROR,
    DATA_NOT_FOUND
}
