package com.atomsail.atombi.data.etl.domain;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * The persistent class for the account_quota database table.
 */
@Entity
@Table(name = "account_quota")
public class AccountQuota implements Serializable {

    @EmbeddedId
    private AccountQuotaPK id;

    @Column(name = "account_quota_created", nullable = false)
    private Date created;

    @Column(name = "account_quota_size", nullable = false, precision = 20, scale = 2)
    private BigDecimal size;

    @Column(name = "account_quota_updated", nullable = false)
    private Date updated;

    @Column(name = "account_quota_used", nullable = false, precision = 20, scale = 2)
    private BigDecimal used;

    @Column(name = "account_id", nullable = false, insertable = false, updatable = false)
    private Long accountId;

    public AccountQuota() {
    }

    public AccountQuotaPK getId() {
        return id;
    }

    public void setId(AccountQuotaPK id) {
        this.id = id;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public BigDecimal getSize() {
        return size;
    }

    public void setSize(BigDecimal size) {
        this.size = size;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public BigDecimal getUsed() {
        return used;
    }

    public void setUsed(BigDecimal used) {
        this.used = used;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    @Override
    public String toString() {
        return "AccountQuota{" +
                "id=" + id +
                ", size=" + size +
                ", used=" + used +
                ", accountId=" + accountId +
                '}';
    }
}