package com.atomsail.atombi.data.etl.domain;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


@Entity
@Table(name = "datasource_config")
public class AtomDBConfig implements Serializable {

    @EmbeddedId
    private AtomDBConfigPK id;

    @Column(name = "datasource_config_created", nullable = false)
    private Date created;

    @Column(name = "datasource_config_updated", nullable = false)
    private Date updated;

    @Lob
    @Type(type = "text")
    @Column(name = "datasource_config_value", nullable = false)
    private String configValue;


    public AtomDBConfig() {
    }

    public AtomDBConfig(AtomDBConfigPK id, Date created, Date updated, String configValue) {
        this.id = id;
        this.created = created;
        this.updated = updated;
        this.configValue = configValue;
    }


    public AtomDBConfigPK getId() {
        return id;
    }

    public void setId(AtomDBConfigPK id) {
        this.id = id;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public String getConfigValue() {
        return configValue;
    }

    public void setConfigValue(String configValue) {
        this.configValue = configValue;
    }

    @Override
    public String toString() {
        return "AtomDBConfig{" +
                "id=" + id +
                ", configValue='" + configValue + '\'' +
                ", updated=" + updated +
                '}';
    }
}
