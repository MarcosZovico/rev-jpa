package com.atomsail.atombi.data.etl.domain;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "datasource")
public class AtomDB {

    @Id
    @GenericGenerator(
            name = "DATASOURCE_DATASOURCEID_GENERATOR",
            strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
            parameters = {
                    @Parameter(name = "sequence_name", value = "DATASOURCE_DATASOURCE_ID_SEQ"),
                    @Parameter(name = "initial_value", value = "1"),
                    @Parameter(name = "increment_size", value = "1")
            }
    )
    @GeneratedValue(generator = "DATASOURCE_DATASOURCEID_GENERATOR")
    @Column(name = "datasource_id", unique = true, nullable = false)
    private Long atomdbId;

    @Column(name = "datasource_created", nullable = false)
    private Date created;

    @Lob
    @Type(type = "text")
    @Column(name = "datasource_description", nullable = false)
    private String description;

    @Column(name = "datasource_name", nullable = false, length = 255)
    private String name;

    @Column(name = "datasource_updated", nullable = false)
    private Date updated;


    // bi-directional many-to-one association to DatasourceField
    @OneToMany(mappedBy = "atomDB")
    private Set<AtomDBField> fields = new HashSet<>();

    // bi-directional many-to-one association to DatasourceField
    @OneToMany(mappedBy = "atomDB")
    private Set<AtomDBAction> actions = new HashSet<>();

    @OneToMany(mappedBy = "atomDB")
    private Set<AtomDBData> atomDBData = new HashSet<>();

    public AtomDB() {

    }

    public Long getAtomdbId() {
        return atomdbId;
    }

    public void setAtomdbId(Long atomdbId) {
        this.atomdbId = atomdbId;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public Set<AtomDBField> getFields() {
        return fields;
    }

    public void setFields(Set<AtomDBField> fields) {
        this.fields = fields;
    }

    @Override
    public String toString() {
        return "AtomDB{" +
                "atomdbId=" + atomdbId +
                ", name='" + name + '\'' +
                ", updated=" + updated +
                '}';
    }

    public Set<AtomDBData> getAtomDBData() {
        return atomDBData;
    }

    public void setAtomDBData(Set<AtomDBData> atomDBData) {
        this.atomDBData = atomDBData;
    }

    public Set<AtomDBAction> getActions() {
        return actions;
    }

    public void setActions(Set<AtomDBAction> actions) {
        this.actions = actions;
    }
}


