package com.atomsail.atombi.data.etl.domain;

/**
 * Created by msouza on 13/07/17.
 */
public enum AtomDBActionType {
    ADD,
    REMOVE,
    BACKUP,
    RUN_ETL,
    /**
     * Exporta os dados de uma dimensão fazendo select distinct,
     * e delete todos os registros e importa novamente.
     */
    REBUILD_DIMENSION,
    /**
     * Remove os registro que estão em uma dimensão
     * mas não existem na tabela de fatos
     */
    CLEAN_DIMENSION_ORPHAN,
    /**
     * Limpa o cache para uma bade de dados e atualiza os status da carga.
     */
    CLEAN_CACHE,
    /**
     * Atualiza uma dimensão mantendo a integridades dos dados ao
     * remover e adicionar dados de uma base de dados.
     */
    UPDATE_DIMENSION
}
