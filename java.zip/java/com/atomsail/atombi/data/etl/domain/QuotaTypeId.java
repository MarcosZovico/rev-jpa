package com.atomsail.atombi.data.etl.domain;


/**
 * @author Marcos Souza
 * @version 1.0
 * @created 19-abr-2016 13:44:10
 */
public enum QuotaTypeId {
	USER,
	STORAGE,
	EMBEDDED_VIEW,
	FEATURE
}