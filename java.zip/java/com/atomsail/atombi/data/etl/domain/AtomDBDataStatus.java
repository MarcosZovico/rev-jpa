package com.atomsail.atombi.data.etl.domain;

public enum AtomDBDataStatus {
    /**
     * Cria a base de dados analitica do cubo no monetdb
     */
    CREATING_ANALYTIC_DB,
    /**
     * Cria o schema do mondrian para o cubo
     */
    CREATING_MONDRIAN_SCHEMA,

    /**
     * Cria transformação ETL
     */
    CREATING_ETL_TRANS,

    /**
     * Executa transformação ETL
     */
    RUNNING_ETL_TRANS,

    /**
     * Finalizado ETL aguandando para popular dados
     */
    WAITING,
    /**
     * Load fact table
     */
    FACT_LOAD,
    /**
     * Completed
     */
    COMPLETED,
    /**
     * Error in proccess
     */
    ERROR,
    /**
     * DatasourceData foi excluido
     */
    DELETED,

    /**
     * Removendo dados de CubeData
     */
    REMOVING,

    /**
     * Atualizando dimensões
     */
    UPDATING_DIMENSION,

    NO_DATA
}
