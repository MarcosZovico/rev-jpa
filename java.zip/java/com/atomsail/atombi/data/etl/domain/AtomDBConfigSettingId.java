package com.atomsail.atombi.data.etl.domain;


/**
 * @author Marcos Souza
 * @version 1.0
 * @created 19-abr-2016 13:44:09
 */
public enum AtomDBConfigSettingId {
	TYPE,
	DRIVER,
	HOST,
	PORT,
	INSTANCE,
	DATABASE,
	SCHEMA,
	USERNAME,
	PASSWORD
}