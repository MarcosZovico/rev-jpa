package com.atomsail.atombi.data.etl.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.io.Serializable;

/**
 * The primary key class for the datasource_data_attribute database table.
 */
@Embeddable
public class AtomDBDataAttributePK implements Serializable {

    @Column(name = "datasource_data_id", insertable = false, updatable = false, nullable = false)
    private Long atomdbDataId;

    @Enumerated(EnumType.STRING)
    @Column(name = "data_input_attribute_id", insertable = false, updatable = false, nullable = false, length = 64)
    private AtomDBDataAttributeType atomdbDataAttribute;

    public AtomDBDataAttributePK() {
    }

    public AtomDBDataAttributePK(Long atomdbDataId, AtomDBDataAttributeType atomdbDataAttribute) {
        this.atomdbDataId = atomdbDataId;
        this.atomdbDataAttribute = atomdbDataAttribute;
    }

    public Long getAtomdbDataId() {
        return atomdbDataId;
    }

    public void setAtomdbDataId(Long atomdbDataId) {
        this.atomdbDataId = atomdbDataId;
    }

    public AtomDBDataAttributeType getAtomdbDataAttribute() {
        return atomdbDataAttribute;
    }

    public void setAtomdbDataAttribute(AtomDBDataAttributeType atomdbDataAttribute) {
        this.atomdbDataAttribute = atomdbDataAttribute;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AtomDBDataAttributePK that = (AtomDBDataAttributePK) o;

        if (atomdbDataId != null ? !atomdbDataId.equals(that.atomdbDataId) : that.atomdbDataId != null) return false;
        return atomdbDataAttribute != null ? atomdbDataAttribute.equals(that.atomdbDataAttribute) : that.atomdbDataAttribute == null;
    }

    @Override
    public int hashCode() {
        int result = atomdbDataId != null ? atomdbDataId.hashCode() : 0;
        result = 31 * result + (atomdbDataAttribute != null ? atomdbDataAttribute.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "AtomDBDataAttributePK{" +
                "atomdbDataId=" + atomdbDataId +
                ", atomdbDataAttribute='" + atomdbDataAttribute + '\'' +
                '}';
    }
}