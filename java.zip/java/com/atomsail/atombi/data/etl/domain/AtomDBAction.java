package com.atomsail.atombi.data.etl.domain;



import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


@Entity
@Table(name = "datasource_db_action")
public class AtomDBAction implements Serializable {

    @Id
    @GenericGenerator(
            name = "DATASOURCE_DB_ACTION_DATASOURCE_DB_ACTIONID_GENERATOR",
            strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
            parameters = {
                    @Parameter(name = "sequence_name", value = "DATASOURCE_DB_ACTION_DATASOURCE_DB_ACTION_ID_SEQ"),
                    @Parameter(name = "initial_value", value = "1"),
                    @Parameter(name = "increment_size", value = "1")
            }
    )
    @GeneratedValue(generator = "DATASOURCE_DB_ACTION_DATASOURCE_DB_ACTIONID_GENERATOR")
    @Column(name = "datasource_db_action_id", unique = true, nullable = false)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "datasource_db_action_action", nullable = false, length = 64)
    private AtomDBActionType action;

    @Enumerated(EnumType.STRING)
    @Column(name = "datasource_db_action_status", nullable = false, length = 64)
    private AtomDBActionStatus status;

    @Lob
    @Type(type = "text")
    @Column(name = "datasource_db_action_config", nullable = false)
    private String config;

    @Column(name = "datasource_db_action_created", nullable = false)
    private Date created;

    @Column(name = "datasource_db_action_updated", nullable = false)
    private Date updated;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "datasource_id", nullable = false)
    private AtomDB atomDB;

    public AtomDBAction() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public AtomDBActionType getAction() {
        return action;
    }

    public void setAction(AtomDBActionType action) {
        this.action = action;
    }

    public AtomDBActionStatus getStatus() {
        return status;
    }

    public void setStatus(AtomDBActionStatus status) {
        this.status = status;
    }

    public String getConfig() {
        return config;
    }

    public void setConfig(String config) {
        this.config = config;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    @Override
    public String toString() {
        return "AtomDBAction{" +
                "id=" + id +
                ", action=" + action +
                ", status=" + status +
                ", config='" + config + '\'' +
                ", updated=" + updated +
                '}';
    }

    public AtomDB getAtomDB() {
        return atomDB;
    }

    public void setAtomDB(AtomDB atomDB) {
        this.atomDB = atomDB;
    }
}