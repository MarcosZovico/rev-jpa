package com.atomsail.atombi.data.etl.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.io.Serializable;

/**
 * The primary key class for the datasource_config database table.
 */
@Embeddable
public class AtomDBConfigPK implements Serializable {

    @Column(name = "datasource_id", insertable = false, updatable = false, nullable = false)
    private Long atomdbId;

    @Enumerated(EnumType.STRING)
    @Column(name = "datasource_setting_id", insertable = false, updatable = false, nullable = false, length = 32)
    private AtomDBConfigSettingId settingId;

    public AtomDBConfigPK() {
    }

    public AtomDBConfigPK(Long atomdbId, AtomDBConfigSettingId settingId) {
        this.atomdbId = atomdbId;
        this.settingId = settingId;
    }

    public Long getAtomdbId() {
        return atomdbId;
    }

    public void setAtomdbId(Long atomdbId) {
        this.atomdbId = atomdbId;
    }

    public AtomDBConfigSettingId getSettingId() {
        return settingId;
    }

    public void setSettingId(AtomDBConfigSettingId settingId) {
        this.settingId = settingId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AtomDBConfigPK that = (AtomDBConfigPK) o;

        if (atomdbId != null ? !atomdbId.equals(that.atomdbId) : that.atomdbId != null) return false;
        return settingId == that.settingId;
    }

    @Override
    public int hashCode() {
        int result = atomdbId != null ? atomdbId.hashCode() : 0;
        result = 31 * result + (settingId != null ? settingId.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "AtomDBConfigPK{" +
                "atomdbId=" + atomdbId +
                ", settingId=" + settingId +
                '}';
    }
}