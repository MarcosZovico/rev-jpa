package com.atomsail.atombi.data.etl.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.io.Serializable;

/**
 * The primary key class for the account_quota database table.
 */
@Embeddable
public class AccountQuotaPK implements Serializable {


    @Column(name = "account_id", insertable = false, updatable = false, nullable = false)
    private Long accountId;

    @Enumerated(EnumType.STRING)
    @Column(name = "quota_type_id", insertable = false, updatable = false, nullable = false, length = 32)
    private QuotaTypeId quotaTypeId;

    public AccountQuotaPK() {
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public QuotaTypeId getQuotaTypeId() {
        return quotaTypeId;
    }

    public void setQuotaTypeId(QuotaTypeId quotaTypeId) {
        this.quotaTypeId = quotaTypeId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AccountQuotaPK that = (AccountQuotaPK) o;

        if (accountId != null ? !accountId.equals(that.accountId) : that.accountId != null) return false;
        return quotaTypeId == that.quotaTypeId;
    }

    @Override
    public int hashCode() {
        int result = accountId != null ? accountId.hashCode() : 0;
        result = 31 * result + (quotaTypeId != null ? quotaTypeId.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "AccountQuotaPK{" +
                "accountId=" + accountId +
                ", quotaTypeId=" + quotaTypeId +
                '}';
    }
}