package com.atomsail.atombi.data.etl.domain;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "datasource_field")
public class AtomDBField {

    @Id
    @GenericGenerator(
            name = "DATASOURCE_FIELD_DATASOURCEFIELDID_GENERATOR",
            strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
            parameters = {
                    @Parameter(name = "sequence_name", value = "DATASOURCE_FIELD_DATASOURCE_FIELD_ID_SEQ"),
                    @Parameter(name = "initial_value", value = "1"),
                    @Parameter(name = "increment_size", value = "1")
            }
    )
    @GeneratedValue(generator = "DATASOURCE_FIELD_DATASOURCEFIELDID_GENERATOR")
    @Column(name = "datasource_field_id", unique = true, nullable = false)
    private Long fieldId;

    @Column(name = "datasource_field_aggregation", length = 32)
    private String aggregation;

    @Column(name = "datasource_field_column", length = 32)
    private String column;

    @Column(name = "datasource_field_created", nullable = false)
    private Date created;

    @Lob
    @Type(type = "text")
    @Column(name = "datasource_field_description")
    private String description;

    @Lob
    @Type(type = "text")
    @Column(name = "datasource_field_formula")
    private String formula;

    @Column(name = "datasource_field_mask", length = 32)
    private String mask;

    @Column(name = "datasource_field_type_id")
    private String type;

    @Column(name = "datasource_field_name", nullable = false, length = 255)
    private String name;

    @Column(name = "datasource_field_updated", nullable = false)
    private Date updated;

    @Column(name = "datasource_field_order", nullable = false)
    private Integer order;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "datasource_id", nullable = false)
    private AtomDB atomDB;

    public AtomDBField() {
    }

    public Long getFieldId() {
        return fieldId;
    }

    public void setFieldId(Long fieldId) {
        this.fieldId = fieldId;
    }

    public String getAggregation() {
        return aggregation;
    }

    public void setAggregation(String aggregation) {
        this.aggregation = aggregation;
    }

    public String getColumn() {
        return column;
    }

    public void setColumn(String column) {
        this.column = column;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFormula() {
        return formula;
    }

    public void setFormula(String formula) {
        this.formula = formula;
    }

    public String getMask() {
        return mask;
    }

    public void setMask(String mask) {
        this.mask = mask;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public Integer getOrder() {
        return order;
    }

    public void setOrder(Integer order) {
        this.order = order;
    }


    @Override
    public String toString() {
        return "AtomDBField{" +
                "fieldId=" + fieldId +
                ", aggregation='" + aggregation + '\'' +
                ", column='" + column + '\'' +
                ", formula='" + formula + '\'' +
                ", mask='" + mask + '\'' +
                ", name='" + name + '\'' +
                ", order=" + order +
                '}';
    }

    public AtomDB getAtomDB() {
        return atomDB;
    }

    public void setAtomDB(AtomDB atomDB) {
        this.atomDB = atomDB;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFieldName() {
        return "field" + this.fieldId;
    }

    public String getSourceFieldName() {
        return "s" + getAtomDB().getAtomdbId() + "_" + getFieldName();
    }

    public String getSourceFieldValue() {
        return getSourceFieldName() + "_value";
    }

    public String getSourceFieldNameId() {
        return getSourceFieldName() + "_id";
    }
}


