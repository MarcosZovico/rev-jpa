package com.atomsail.atombi.data.etl.dto;

import java.io.Serializable;

/**
 * Created by msouza on 13/07/17.
 */
public class AtomDBActionConfigDTO implements Serializable {

    private Long cubeDataId;
    private Long cubeId;
    private Long accountId;
    private String refCode;
    private Long fieldId;

    public AtomDBActionConfigDTO() {
    }

    public AtomDBActionConfigDTO(Long cubeDataId, Long cubeId, Long accountId) {
        this.cubeDataId = cubeDataId;
        this.cubeId = cubeId;
        this.accountId = accountId;
    }

    public AtomDBActionConfigDTO(String refCode, Long cubeId, Long accountId) {
        this.refCode = refCode;
        this.cubeId = cubeId;
        this.accountId = accountId;
    }

    public Long getCubeDataId() {
        return cubeDataId;
    }

    public void setCubeDataId(Long cubeDataId) {
        this.cubeDataId = cubeDataId;
    }

    public Long getCubeId() {
        return cubeId;
    }

    public void setCubeId(Long cubeId) {
        this.cubeId = cubeId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public String getRefCode() {
        return refCode;
    }

    public void setRefCode(String refCode) {
        this.refCode = refCode;
    }

    public Long getFieldId() {
        return fieldId;
    }

    public void setFieldId(Long fieldId) {
        this.fieldId = fieldId;
    }

}
