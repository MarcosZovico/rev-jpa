package com.atomsail.atombi.data.etl.dto;

import java.io.Serializable;

public class AtomdbDataDTO implements Serializable {

    private Long accountId;
    private Long cubeId;
    private Long cubeDataId;
    private Long actionId;
    private Boolean hasData = Boolean.TRUE;
    private Long userId;
    private String uuid;
    private ETLTransType type;

    public enum ETLTransType {
        LOAD_DATA,
        EXPORT_DATA
    }

    public AtomdbDataDTO() {

    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Long getCubeId() {
        return cubeId;
    }

    public void setCubeId(Long cubeId) {
        this.cubeId = cubeId;
    }

    public Long getCubeDataId() {
        return cubeDataId;
    }

    public void setCubeDataId(Long cubeDataId) {
        this.cubeDataId = cubeDataId;
    }

    public Long getActionId() {
        return actionId;
    }

    public void setActionId(Long actionId) {
        this.actionId = actionId;
    }

    public Boolean getHasData() {
        return hasData;
    }

    public void setHasData(Boolean hasData) {
        this.hasData = hasData;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public ETLTransType getType() {
        return type;
    }

    public void setType(ETLTransType type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "AtomdbDataDTO{" +
                "accountId=" + accountId +
                ", cubeId=" + cubeId +
                ", cubeDataId=" + cubeDataId +
                ", actionId=" + actionId +
                ", hasData=" + hasData +
                ", userId=" + userId +
                ", uuid='" + uuid + '\'' +
                ", type=" + type +
                '}';
    }
}
