package com.atomsail.atombi.data.etl.databases;

public enum DatabaseType {

    MonetDb("jdbc:monetdb://{0}:{1}/{2}"),
    MySQL("jdbc:mysql://{0}:{1}/{2}?useSSL=false"),
    MariaDb("jdbc:mariadb://{0}:{1}/{2}");

    private String jdbcTemplate;

    DatabaseType(String jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public String getJdbcTemplate() {
        return jdbcTemplate;
    }

}
