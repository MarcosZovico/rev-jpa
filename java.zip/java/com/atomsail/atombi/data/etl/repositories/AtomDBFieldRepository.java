package com.atomsail.atombi.data.etl.repositories;

import com.atomsail.atombi.data.etl.domain.AtomDBField;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AtomDBFieldRepository extends JpaRepository<AtomDBField, Long> {


    List<AtomDBField> findByAtomDB_AtomdbId(Long atomdbId);
    List<AtomDBField> findByAtomDB_AtomdbIdOrderByOrder(Long atomdbId);

    List<AtomDBField> findByAtomDB_AtomdbIdAndTypeOrderByOrder(Long atomdbId, String type);
}
