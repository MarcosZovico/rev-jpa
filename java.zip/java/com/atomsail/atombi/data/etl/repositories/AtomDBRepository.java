package com.atomsail.atombi.data.etl.repositories;

import com.atomsail.atombi.data.etl.domain.AtomDB;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AtomDBRepository extends JpaRepository<AtomDB, Long> {


}
