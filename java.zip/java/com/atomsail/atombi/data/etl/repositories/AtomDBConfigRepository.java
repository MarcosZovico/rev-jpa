package com.atomsail.atombi.data.etl.repositories;

import com.atomsail.atombi.data.etl.domain.AtomDBConfig;
import com.atomsail.atombi.data.etl.domain.AtomDBConfigPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AtomDBConfigRepository extends JpaRepository<AtomDBConfig, AtomDBConfigPK> {

    /**
     * Litas todas configurações de um AtomDB
     * @param atomdbId Codigo do AtomDB
     * @return
     */
    List<AtomDBConfig> findById_AtomdbId(Long atomdbId);

    AtomDBConfig findById(AtomDBConfigPK id);
}
