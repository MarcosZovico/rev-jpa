package com.atomsail.atombi.data.etl.repositories;

import com.atomsail.atombi.data.etl.domain.AtomDBAction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AtomDBActionRepository extends JpaRepository<AtomDBAction, Long> {
}
