package com.atomsail.atombi.data.etl.repositories;

import com.atomsail.atombi.data.etl.domain.AtomDBData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AtomDBDataRepository extends JpaRepository<AtomDBData, Long> {
}
