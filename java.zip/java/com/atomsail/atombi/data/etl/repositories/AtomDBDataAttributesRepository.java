package com.atomsail.atombi.data.etl.repositories;

import com.atomsail.atombi.data.etl.domain.AtomDBDataAttribute;
import com.atomsail.atombi.data.etl.domain.AtomDBDataAttributePK;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AtomDBDataAttributesRepository extends JpaRepository<AtomDBDataAttribute, AtomDBDataAttributePK> {

    List<AtomDBDataAttribute> findAtomdbDataAttributeById_AtomdbDataId(Long atomdbDataId);
}
