package com.atomsail.atombi.data.etl.repositories;

import com.atomsail.atombi.data.etl.domain.AccountQuota;
import com.atomsail.atombi.data.etl.domain.AccountQuotaPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountQuotaRepository extends JpaRepository<AccountQuota, AccountQuotaPK> {
}
