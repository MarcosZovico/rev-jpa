package com.atomsail.atombi.data.etl.utils;

import com.atomsail.atombi.data.etl.domain.AtomDBDataAttribute;
import com.atomsail.atombi.data.etl.domain.AtomDBDataAttributeType;

import java.util.List;
import java.util.Optional;

public class AtomdbDataAttributeUtil {


    public static Optional<AtomDBDataAttribute> get(AtomDBDataAttributeType attributeType, List<AtomDBDataAttribute> attributes) {
        return attributes.stream().filter(f -> f.getId().getAtomdbDataAttribute().equals(attributeType)).findFirst();
    }
}
