package com.atomsail.atombi.data.etl.utils;

import java.text.MessageFormat;

public class AtomDBSqlUtils {

    private AtomDBSqlUtils() {

    }

    public static String cleanDimension(Long accountId, Long atomdbId, Long fieldId) {
        String schema = "a" + accountId;
        String factTable = "s" + atomdbId;
        String dimensionTable = "s" + atomdbId + "_field" + fieldId + "";

        String sqlTemplate = "DELETE FROM {0}.{2} WHERE NOT EXISTS" +
                "(SELECT NULL FROM {0}.{1} WHERE {1}.{2}_id = {2}.{2}_id )";

        String sql = MessageFormat.format(sqlTemplate, schema, factTable, dimensionTable);

        return sql;
    }

    public static String createTempDistinctData(Long accountId, Long atomdbId, Long fieldId) {

        String sqlTemplate = "CREATE TEMPORARY TABLE IF NOT EXISTS a{0,number,#}.s{1,number,#}_field{2,number,#}_temp AS (SELECT" +
                " min(s{1,number,#}_cube_data_id) as s{1,number,#}_cube_data_id," +
                " s{1,number,#}_field{2,number,#}_id," +
                " s{1,number,#}_field{2,number,#}_value," +
                " s{1,number,#}_field{2,number,#}_md5," +
                " min(s{1,number,#}_field{2,number,#}_created) as created" +
                " FROM a{0,number,#}.s{1,number,#}_field{2,number,#}" +
                " GROUP BY s{1,number,#}_field{2,number,#}_id," +
                " s{1,number,#}_field{2,number,#}_value, s{1,number,#}_field{2,number,#}_md5)";

        String sql = MessageFormat.format(sqlTemplate, accountId, atomdbId, fieldId);

        return sql;
    }

    public static String deleteAll(Long accountId, Long atomdbId, Long fieldId) {

        String sqlTemplate = "delete from a{0,number,#}.s{1,number,#}_field{2,number,#}";

        String sql = MessageFormat.format(sqlTemplate, accountId, atomdbId, fieldId);

        return sql;
    }

    public static String reloadTable(Long accountId, Long atomdbId, Long fieldId) {

        String sqlTemplate = "insert into a{0,number,#}.s{1,number,#}_field{2,number,#} (select * from a{0,number,#}.s{1,number,#}_field{2,number,#}_temp)";

        String sql = MessageFormat.format(sqlTemplate, accountId, atomdbId, fieldId);

        return sql;
    }
}
