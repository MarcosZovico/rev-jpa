package com.atomsail.atombi.data.etl.utils;

import com.atomsail.atombi.data.etl.dto.FieldInputMapDTO;

import java.util.List;
import java.util.Optional;

public class FromToMapUtil {

    private FromToMapUtil() {

    }

    public static Optional<FieldInputMapDTO> getFieldByOrder(List<FieldInputMapDTO> fields, Integer order) {

        return fields.stream().filter(f -> order.equals(f.getOrder())).findFirst();

    }


}
