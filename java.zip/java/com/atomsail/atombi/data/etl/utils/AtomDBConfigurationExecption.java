package com.atomsail.atombi.data.etl.utils;

public class AtomDBConfigurationExecption extends RuntimeException {
    public AtomDBConfigurationExecption() {
    }

    public AtomDBConfigurationExecption(String message) {
        super(message);
    }

    public AtomDBConfigurationExecption(String message, Throwable cause) {
        super(message, cause);
    }

    public AtomDBConfigurationExecption(Throwable cause) {
        super(cause);
    }

    public AtomDBConfigurationExecption(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
