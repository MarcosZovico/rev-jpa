package com.atomsail.atombi.data.etl.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;

/**
 * Created by msouza on 02/02/18.
 */
@Component
public class JobParameterUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(JobParameterUtil.class);

    @Autowired
    private ObjectMapper mapper;

    public JobParameterUtil() {

    }

    public static void addString(ChunkContext chunkContext, String key, String value) {
        chunkContext.getStepContext()
                .getStepExecution()
                .getJobExecution()
                .getExecutionContext()
                .putString(key, value);
    }

    public <T> T getParameter(ChunkContext chunkContext, String key, Class<T> klass) throws IOException {

        String jsonRef = getString(chunkContext, key);
        T cloneRef = mapper.readValue(jsonRef, klass);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Referencia encontrada {}", cloneRef);
        }

        return cloneRef;
    }


    public <T> T getRunTimeParameter(JobExecution jobExecution, String key, Class<T> klass) throws IOException {

        String jsonRef = jobExecution.getExecutionContext().getString(key);
        T cloneRef = mapper.readValue(jsonRef, klass);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Referencia encontrada {}", cloneRef);
        }

        return cloneRef;
    }

    public <T> T getRunTimeParameter(ChunkContext chunkContext, String key, Class<T> klass) throws IOException {

        try {

            String jsonRef = getRunTimeString(chunkContext, key);
            T cloneRef = mapper.readValue(jsonRef, klass);

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Referencia encontrada {} para a chave {}", cloneRef, key);
            }

            return cloneRef;
        } catch (Exception e) {

            String jsonRef = getString(chunkContext, key);
            T cloneRef = mapper.readValue(jsonRef, klass);

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Referencia encontrada {} para a chave {}", cloneRef, key);
            }

            return cloneRef;
        }
    }

    public <T> T getParameter(JobExecution jobExecution, String key, Class<T> klass) throws IOException {

        String jsonRef = getString(jobExecution, key);
        T cloneRef = mapper.readValue(jsonRef, klass);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Referencia encontrada {}", cloneRef);
        }

        return cloneRef;
    }

    public static String getString(ChunkContext chunkContext, String key) {
        return chunkContext.getStepContext().getStepExecution().getJobParameters().getString(key);
    }

    public static String getRunTimeString(ChunkContext chunkContext, String key) {
        try {
            return chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().getString(key);
        } catch (Exception e) {
            return getString(chunkContext, key);
        }
    }


    public static Long getLong(ChunkContext chunkContext, String key) {
        return chunkContext.getStepContext().getStepExecution().getJobParameters().getLong(key);
    }

    public static String getString(JobExecution jobExecution, String key) {
        return jobExecution.getJobParameters().getString(key);
    }

    public String writeValueAsString(Object value) throws JsonProcessingException {
        return mapper.writeValueAsString(value);
    }

    public <T> List<T> toList(String value, Class<T> klass) throws IOException {
        CollectionType listType = mapper.getTypeFactory().constructCollectionType(List.class, klass);
        return mapper.readValue(value, listType);
    }

    public <T> List<T> toRunTimeList(ChunkContext chunkContext, String key, Class<T> klass) throws IOException {
        return toRunTimeList(chunkContext.getStepContext().getStepExecution().getJobExecution(), key, klass);
    }


    public <T> List<T> toRunTimeList(JobExecution jobExecution, String key, Class<T> klass) throws IOException {
        try {
            String value = jobExecution.getExecutionContext().getString(key);
            return toList(value, klass);
        } catch (Exception e) {
            String value = getString(jobExecution, key);
            return toList(value, klass);
        }
    }

}
