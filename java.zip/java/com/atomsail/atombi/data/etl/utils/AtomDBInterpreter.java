package com.atomsail.atombi.data.etl.utils;

import com.atomsail.atombi.data.etl.cipher.AtomCipher;
import com.atomsail.atombi.data.etl.cipher.CreateCipherException;
import com.atomsail.atombi.data.etl.databases.DatabaseType;
import com.atomsail.atombi.data.etl.domain.AtomDBConfig;
import com.atomsail.atombi.data.etl.domain.AtomDBConfigSettingId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

import java.text.MessageFormat;
import java.util.List;
import java.util.Optional;

/**
 * Classe que interpreta a configuracao do banco de dados
 */
public class AtomDBInterpreter implements InitializingBean {

    private static final Logger log = LoggerFactory.getLogger(AtomDBInterpreter.class);

    private List<AtomDBConfig> dbConfigs;

    private AtomCipher atomCipher;


    public AtomDBInterpreter(List<AtomDBConfig> dbConfigs) {
        this.dbConfigs = dbConfigs;
    }


    /**
     * Recupera a conexão jdbc do banco de dados
     *
     * @return
     * @throws AtomDBConfigurationExecption
     */
    public String getJdbcUrl() throws AtomDBConfigurationExecption {


        DatabaseType databaseType = getDatabaseType();

        String jdbcUrl = MessageFormat.format(databaseType.getJdbcTemplate()
                , getHost()
                , getPort()
                , getDatabase()
        );

        if (log.isDebugEnabled()) {
            log.debug("jdbc criado para o banco de dados: {}", jdbcUrl);
        }

        return jdbcUrl;
    }

    public String getJdbcUrlSpark() {
        DatabaseType databaseType = getDatabaseType();

        String template = databaseType.getJdbcTemplate();

        if (databaseType.equals(DatabaseType.MariaDb)) {
            template = template.replaceAll("mariadb", "mysql");
        }

        String jdbcUrl = MessageFormat.format(template
                , getHost()
                , getPort()
                , getDatabase()
        );

        if (log.isDebugEnabled()) {
            log.debug("jdbc criado para o banco de dados: {}", jdbcUrl);
        }

        return jdbcUrl;
    }

    public DatabaseType getDatabaseType() {
        return DatabaseType.valueOf(getProperty(AtomDBConfigSettingId.TYPE));
    }

    public String getHost() {
        return getProperty(AtomDBConfigSettingId.HOST);
    }

    public String getPort() {
        return getProperty(AtomDBConfigSettingId.PORT);
    }

    public String getDriver() {
        return getProperty(AtomDBConfigSettingId.DRIVER);
    }

    public String getPassword() {
        try {

            return atomCipher.decrypt(getProperty(AtomDBConfigSettingId.PASSWORD));

        } catch (CreateCipherException e) {
            log.error(e.getMessage(), e);
            throw new AtomDBConfigurationExecption(e);
        }
    }

    public String getUser() {
        return getProperty(AtomDBConfigSettingId.USERNAME);
    }

    public String getDatabase() {
        return getProperty(AtomDBConfigSettingId.DATABASE);

    }

    private String getProperty(AtomDBConfigSettingId settingId) {
        Optional<AtomDBConfig> atomdbConfig = dbConfigs.stream().filter(dbConfig -> settingId.equals(dbConfig.getId().getSettingId())).findFirst();
        if (log.isTraceEnabled()) {
            log.trace("atomdbConfig: {}", atomdbConfig);
        }
        return atomdbConfig.get().getConfigValue();
    }

    public void setAtomCipher(AtomCipher atomCipher) {
        this.atomCipher = atomCipher;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(atomCipher, "atomCipher must be set");
    }


}
