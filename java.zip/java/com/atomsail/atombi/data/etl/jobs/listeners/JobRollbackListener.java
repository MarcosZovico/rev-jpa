package com.atomsail.atombi.data.etl.jobs.listeners;

import com.atomsail.atombi.data.etl.cipher.AtomCipher;
import com.atomsail.atombi.data.etl.domain.AtomDBConfig;
import com.atomsail.atombi.data.etl.domain.AtomDBField;
import com.atomsail.atombi.data.etl.repositories.AtomDBConfigRepository;
import com.atomsail.atombi.data.etl.repositories.AtomDBFieldRepository;
import com.atomsail.atombi.data.etl.utils.AtomDBInterpreter;
import com.atomsail.atombi.data.etl.utils.AtomDBSqlUtils;
import com.atomsail.atombi.databases.AnalyticDatabaseConfig;
import com.atomsail.atombi.databases.dao.AnalyticDatabaseDAO;
import com.atomsail.atombi.databases.dao.AnalyticDatabaseExecuteStatementException;
import com.atomsail.atombi.databases.dto.FieldType;
import com.atomsail.atombi.databases.mariadb.MariaDbAnalyticDatabaseConfig;
import com.atomsail.atombi.databases.monetdb.dao.MonetdbAnalyticDatabaseDAOImpl;
import com.atomsail.atombi.databases.monetdb.db.MonetdbAnalyticDatabaseConfig;
import com.atomsail.atombi.databases.mysql.MySQLAnalyticDatabaseConfig;
import com.atomsail.atombi.databases.mysql.dao.MySQLAnalyticDatabaseDAOImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

public class JobRollbackListener implements JobExecutionListener {

    private static final Logger log = LoggerFactory.getLogger(JobRollbackListener.class);

    @Autowired
    private AtomDBConfigRepository dbConfigRepository;

    @Autowired
    private AtomDBFieldRepository fieldRepository;

    @Autowired
    private AtomCipher atomCipher;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        if (log.isDebugEnabled()) {
            log.debug("-- Job {} ERROR HANDLER com ID {}: INICIADO", jobExecution.getJobInstance().getJobName(), jobExecution.getJobId());
        }
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void afterJob(JobExecution jobExecution) {

        AnalyticDatabaseConfig analyticDatabaseConfig = null;
        AnalyticDatabaseDAO databaseDAO = null;

        Long accountId = jobExecution.getJobParameters().getLong("accountId");
        Long atomdbId = jobExecution.getJobParameters().getLong("atomdbId");
        Long atomdbDataId = jobExecution.getJobParameters().getLong("atomdbDataId");


        // recupera configuracoes do banco de dados
        List<AtomDBConfig> dbConfigs = dbConfigRepository.findById_AtomdbId(atomdbId);
        AtomDBInterpreter dbInterpreter = new AtomDBInterpreter(dbConfigs);
        dbInterpreter.setAtomCipher(atomCipher);

        List<AtomDBField> fields = fieldRepository.findByAtomDB_AtomdbIdAndTypeOrderByOrder(atomdbId, FieldType.TEXT.name());



        switch (dbInterpreter.getDatabaseType()) {

            case MonetDb:

                analyticDatabaseConfig = new MonetdbAnalyticDatabaseConfig(
                        dbInterpreter.getDatabase(),
                        dbInterpreter.getUser(),
                        dbInterpreter.getPassword(),
                        dbInterpreter.getHost(),
                        dbInterpreter.getPort());
                databaseDAO = new MonetdbAnalyticDatabaseDAOImpl();
                break;
            case MySQL:

                analyticDatabaseConfig = new MySQLAnalyticDatabaseConfig(
                        dbInterpreter.getDatabase(),
                        dbInterpreter.getHost(),
                        dbInterpreter.getPort(),
                        dbInterpreter.getUser(),
                        dbInterpreter.getPassword()
                );
                databaseDAO = new MySQLAnalyticDatabaseDAOImpl();
                break;
            case MariaDb:
                analyticDatabaseConfig = new MariaDbAnalyticDatabaseConfig(
                        dbInterpreter.getDatabase(),
                        dbInterpreter.getHost(),
                        dbInterpreter.getPort(),
                        dbInterpreter.getUser(),
                        dbInterpreter.getPassword()
                );
                databaseDAO = new MySQLAnalyticDatabaseDAOImpl();
                break;
        }

        if (jobExecution.getStatus() == BatchStatus.FAILED) {

            try {

                String table = "a" + accountId + ".s" + atomdbId;
                String fieldId = "s" + atomdbId + "_cube_data_id";

                List<String> statements = new ArrayList<>();


                statements.add("delete from " + table + " where " + fieldId + " = " + atomdbDataId);

                for (AtomDBField textField : fields) {
                    statements.add(AtomDBSqlUtils.cleanDimension(accountId, atomdbId, textField.getFieldId()));
                }


                if (log.isDebugEnabled()) {
                    statements.forEach(statement -> log.debug("sql a ser executado {}", statement));
                }

                databaseDAO.executeStatement(statements, analyticDatabaseConfig);

                log.info("rollback realizado com sucesso para atomdbId=[{}] -> entry -> [{}]", atomdbId, atomdbDataId);
            } catch (AnalyticDatabaseExecuteStatementException e) {
                log.error(e.getMessage(), e);
            }

        }
        if (log.isDebugEnabled()) {
            log.debug("-- Job {} ROLLBACK HANDLER com ID {}: FINALIZADO", jobExecution.getJobInstance().getJobName(), jobExecution.getJobId());
        }
    }

    public void setDbConfigRepository(AtomDBConfigRepository dbConfigRepository) {
        this.dbConfigRepository = dbConfigRepository;
    }

    public void setFieldRepository(AtomDBFieldRepository fieldRepository) {
        this.fieldRepository = fieldRepository;
    }

    public void setAtomCipher(AtomCipher atomCipher) {
        this.atomCipher = atomCipher;
    }
}
