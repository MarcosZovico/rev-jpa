package com.atomsail.atombi.data.etl.jobs.star.csv.tasks.files;

import com.atomsail.atombi.data.etl.cipher.AtomCipher;
import com.atomsail.atombi.data.etl.databases.DatabaseType;
import com.atomsail.atombi.data.etl.domain.AtomDBConfig;
import com.atomsail.atombi.data.etl.domain.AtomDBDataAttribute;
import com.atomsail.atombi.data.etl.domain.AtomDBDataAttributeType;
import com.atomsail.atombi.data.etl.domain.AtomDBField;
import com.atomsail.atombi.data.etl.jobs.star.csv.SparkSqlFieldTemplates;
import com.atomsail.atombi.data.etl.jobs.star.csv.SparkSqlFormats;
import com.atomsail.atombi.data.etl.metadata.FieldTypes;
import com.atomsail.atombi.data.etl.repositories.AtomDBConfigRepository;
import com.atomsail.atombi.data.etl.repositories.AtomDBDataAttributesRepository;
import com.atomsail.atombi.data.etl.repositories.AtomDBFieldRepository;
import com.atomsail.atombi.data.etl.utils.AtomDBInterpreter;
import com.atomsail.atombi.data.etl.utils.AtomdbDataAttributeUtil;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.Assert;

import java.text.MessageFormat;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class CreateDimensionFilesFromS3Tasklet implements Tasklet, InitializingBean {

    private static final Logger log = LoggerFactory.getLogger(CreateDimensionFilesFromS3Tasklet.class);

    private Long accountId;
    private Long atomdbId;
    private Long atomdbDataId;
    private Long atomdbActionId;

    @Value("${atombi.data.atomdb.entry.max_rows_per_file:10000}")
    private String maxRowsPerFile;

    @Value("${atombi.data.atomdb.entry.pending_template}")
    private String s3InputTemplate;


    @Value("${atombi.data.atomdb.entry.done_template_dimension}")
    private String s3OutputDimTemplate;


    @Autowired
    private SparkSession sparkSession;

    @Autowired
    private AtomDBFieldRepository fieldRepository;

    @Autowired
    private AtomDBDataAttributesRepository attributesRepository;

    @Autowired
    private AtomDBConfigRepository dbConfigRepository;

    @Autowired
    private AtomCipher atomCipher;

    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {

        log.info("START-DIMENSIONS: iniciando processo de criacao dos arquivos de dimensao para carga: [{}]", atomdbDataId);

        // busca no banco de dados as informações necessárias para processar o arquivo
        List<AtomDBField> fields = fieldRepository.findByAtomDB_AtomdbIdOrderByOrder(atomdbId);
        List<AtomDBDataAttribute> attributes = attributesRepository.findAtomdbDataAttributeById_AtomdbDataId(atomdbDataId);

        Optional<AtomDBDataAttribute> header = AtomdbDataAttributeUtil.get(AtomDBDataAttributeType.HAS_HEADER, attributes);
        Optional<AtomDBDataAttribute> delimiter = AtomdbDataAttributeUtil.get(AtomDBDataAttributeType.DELIMITER, attributes);
        Optional<AtomDBDataAttribute> s3InputFile = AtomdbDataAttributeUtil.get(AtomDBDataAttributeType.S3_URL, attributes);

        List<AtomDBField> sortedFields = fields
                .stream()
                .filter(atomDBField ->
                        atomDBField.getType().equals(FieldTypes.TEXT) ||
                                atomDBField.getType().equals(FieldTypes.NUMBER) ||
                                atomDBField.getType().equals(FieldTypes.DATE)
                ).sorted(Comparator.comparing(AtomDBField::getOrder)).collect(Collectors.toList());


        // cria estrutura de campos com o tamanho encontrado no banco de dados
        StructField[] structFields = new StructField[sortedFields.size()];

        for (int i = 0; i < sortedFields.size(); i++) {
            structFields[i] = new StructField(sortedFields.get(i).getFieldName(), DataTypes.StringType, true, Metadata.empty());
        }

        // associa a estrutura criada para fazer a consulta com um schema personalizado do arquivo csv

        StructType customSchema = new StructType(structFields);

        String inputFile = MessageFormat.format(s3InputTemplate, s3InputFile.get().getValue());

        if (log.isDebugEnabled()) {
            log.debug("customer s3 input file: {}", inputFile);
        }

        Dataset<Row> dataSet = sparkSession
                .read()
                .format("csv")
                .option("header", header.get().getValue())
                .option("codec", "org.apache.hadoop.io.compress.GzipCodec")
                .option("delimiter", delimiter.get().getValue())
                .option("mode", "failFast")
                .option("escape", "\"")
                .schema(customSchema)
                .csv(inputFile);

        if (log.isDebugEnabled()) {
            dataSet.show();
        }


        // nome da tabela temporária criada no spark para leitura das informações do CSV
        String csvTempView = "s" + atomdbId + "_entry" + atomdbDataId + "_dimensions";
        dataSet.createOrReplaceTempView(csvTempView);

        // pega configurações do banco de dados
        List<AtomDBConfig> dbConfigs = dbConfigRepository.findById_AtomdbId(atomdbId);

        AtomDBInterpreter atomDBConfig = new AtomDBInterpreter(dbConfigs);
        atomDBConfig.setAtomCipher(atomCipher);

        fields.parallelStream().filter(dim -> dim.getType().equals("TEXT")).forEach(dimension -> {

            log.info("START-DIMENSION: {}", dimension.getSourceFieldName());

            String dimensionFieldName = dimension.getFieldName();
            String dimensionFieldId = SparkSqlFieldTemplates.getTextMd5FieldNoAlias(dimension.getFieldName(), dimension.getSourceFieldNameId(), true);

            if (atomDBConfig.getDatabaseType() == DatabaseType.MariaDb){
                log.info("Realizando tratamrnto de caracteres especiais para a dimensao {}", dimensionFieldName);
                dimensionFieldName = SparkSqlFieldTemplates.geTextFieldNormalizedAscii(dimension.getFieldName(), dimension.getName());
                dimensionFieldId = SparkSqlFieldTemplates.getTextMd5FieldNormalizedAscii(dimension.getFieldName(), dimension.getName(), true);
            }

            String outputFile = MessageFormat.format(s3OutputDimTemplate, accountId, atomdbId, atomdbDataId, dimension.getFieldId());
            String distinctFileValues = MessageFormat.format("select distinct {0} as file_id, trim({1}) as file_value from {2}",
                                                                     dimensionFieldId,
                                                                     dimensionFieldName,
                                                                     csvTempView
            );


            // carrega informacoes do banco de dados
            Dataset<Row> tableValues = sparkSession.read()
                                                   .format("jdbc")
                                                   .option("url", atomDBConfig.getJdbcUrlSpark())
                                                   .option("dbtable", MessageFormat.format("(select distinct {0} as table_id, {1} as table_value from a{2,number,#}.{3}) data ",
                                                        dimension.getSourceFieldNameId(),
                                                        dimension.getSourceFieldValue(),
                                                        accountId,
                                                        dimension.getSourceFieldName()))
                                                   .option("user", atomDBConfig.getUser())
                                                   .option("driver", atomDBConfig.getDriver())
                                                   .option("password", atomDBConfig.getPassword())
                                                   .load();


            String fileView = dimension.getSourceFieldName() + "_distinct_file";
            String tableView = dimension.getSourceFieldName() + "_distinct_table";

            Dataset<Row> fileFieldSet = sparkSession.sqlContext().sql(distinctFileValues);
            fileFieldSet.createOrReplaceTempView(fileView);
            tableValues.createOrReplaceTempView(tableView);

            String nonExistsQuery = "" +
                    "select file_id, file_value from " + fileView +
                    " where not exists (select null from " + tableView + " where file_id = table_id) " +
                    "";

            if (log.isDebugEnabled()) {
                log.debug("non exist query: {}", nonExistsQuery);
            }

            Dataset<Row> finalSet = sparkSession.sqlContext().sql(nonExistsQuery);

            if (log.isDebugEnabled()) {
                finalSet.show(10, false);
            }

            if (finalSet.count() > 0) {

                String tempView = csvTempView + "_dim" + dimension.getFieldId();
                finalSet.createOrReplaceTempView(tempView);

                // sql que gera o arquivo final
                String fileSql = MessageFormat.format(
                        "select " +
                                "{5,number,#} as s{1,number,#}_cube_data_id, " +
                                "file_id as {2}, " +
                                "file_value as {3}, " +
                                "file_id as {2}_md5, " +
                                "''" + DateTime.now().toString(SparkSqlFormats.TIMESTAMP_FORMAT) + "'' as current_time " +
                                "from {6}",
                        dimension.getFieldName(), // 0
                        atomdbId, // 1
                        dimension.getSourceFieldNameId(), // 2
                        dimension.getSourceFieldValue(), // 3
                        dimension.getSourceFieldName(), // 4
                        atomdbDataId, // 5
                        tempView // 6
                );

                if (log.isDebugEnabled()) {
                    log.debug("field {} sql {}", dimension.getSourceFieldName(), fileSql);
                }

                Dataset<Row> uniqueValues = sparkSession.sqlContext().sql(fileSql);
                if (log.isDebugEnabled()) {
                    log.debug("valores a serem inseridos no banco de dados para o campo {}", dimension.getSourceFieldName());
                    uniqueValues.show(false);
                }


                uniqueValues
                        .coalesce(1)
                        .write()
                        .format("csv")
                        .mode("overwrite") // sobrescreve (remove e cria nova) a pasta no s3 caso já exista
                        .option("delimiter", "|")
                        .option("maxRecordsPerFile", maxRowsPerFile)
                        .option("codec", "org.apache.hadoop.io.compress.GzipCodec")
                        .csv(outputFile);

                log.info("novos registros para {} salvos no arquivo :{}", dimension.getSourceFieldName(), outputFile);
            } else {
                log.info("nao ha valores novos para :{}", dimension.getSourceFieldName());
            }


            log.info("END-DIMENSION {}", dimension.getSourceFieldName());
        });

        log.info("END-DIMENSIONS: finalizado processo de criacao dos arquivos de dimensao para carga: [{}]", atomdbDataId);


        return RepeatStatus.FINISHED;
    }


    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public void setAtomdbId(Long atomdbId) {
        this.atomdbId = atomdbId;
    }

    public void setAtomdbDataId(Long atomdbDataId) {
        this.atomdbDataId = atomdbDataId;
    }

    public void setAtomdbActionId(Long atomdbActionId) {
        this.atomdbActionId = atomdbActionId;
    }

    public void setMaxRowsPerFile(String maxRowsPerFile) {
        this.maxRowsPerFile = maxRowsPerFile;
    }

    public void setS3InputTemplate(String s3InputTemplate) {
        this.s3InputTemplate = s3InputTemplate;
    }

    public void setS3OutputDimTemplate(String s3OutputDimTemplate) {
        this.s3OutputDimTemplate = s3OutputDimTemplate;
    }

    public void setSparkSession(SparkSession sparkSession) {
        this.sparkSession = sparkSession;
    }

    public void setFieldRepository(AtomDBFieldRepository fieldRepository) {
        this.fieldRepository = fieldRepository;
    }

    public void setAttributesRepository(AtomDBDataAttributesRepository attributesRepository) {
        this.attributesRepository = attributesRepository;
    }

    public void setDbConfigRepository(AtomDBConfigRepository dbConfigRepository) {
        this.dbConfigRepository = dbConfigRepository;
    }

    public void setAtomCipher(AtomCipher atomCipher) {
        this.atomCipher = atomCipher;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(accountId, "accountId must be set");
        Assert.notNull(atomdbId, "atomdbId must be set");
        Assert.notNull(atomdbDataId, "atomdbDataId must be set");
        Assert.notNull(atomdbActionId, "atomdbActionId must be set");
    }
}
