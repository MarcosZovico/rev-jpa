package com.atomsail.atombi.data.etl.jobs.star.csv.tasks.insert;

import com.amazonaws.auth.EnvironmentVariableCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.*;
import com.atomsail.atombi.data.etl.cipher.AtomCipher;
import com.atomsail.atombi.data.etl.domain.AtomDBConfig;
import com.atomsail.atombi.data.etl.repositories.AtomDBConfigRepository;
import com.atomsail.atombi.data.etl.utils.AtomDBInterpreter;
import com.atomsail.atombi.databases.AnalyticDatabaseConfig;
import com.atomsail.atombi.databases.dao.AnalyticDatabaseDAO;
import com.atomsail.atombi.databases.monetdb.dao.MonetdbAnalyticDatabaseDAOImpl;
import com.atomsail.atombi.databases.monetdb.db.MonetdbAnalyticDatabaseConfig;
import com.atomsail.atombi.databases.util.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.Assert;

import java.text.MessageFormat;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.zip.GZIPInputStream;

public class MonetdbInsertDataFromS3Tasklet implements Tasklet, InitializingBean {

    private static final Logger log = LoggerFactory.getLogger(MonetdbInsertDataFromS3Tasklet.class);

    private Long accountId;
    private Long atomdbId;
    private Long atomdbDataId;
    private Long atomdbActionId;

    @Value("${aws.profile}")
    private String awsProfile;

    @Value("${aws.region}")
    private String awsRegion;


    @Value("${aws.bucket}")
    private String bucketName;

    @Value("${atombi.data.atomdb.entry.done_template_entry}")
    private String s3EntryTemplate;

    @Autowired
    private AtomDBConfigRepository dbConfigRepository;

    @Autowired
    private AtomCipher atomCipher;

    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {

        if (log.isDebugEnabled()) {
            log.debug("iniciando carga de dados do start schema do atomDB:[{}] e entry:[{}]", atomdbId, atomdbDataId);
        }

        // recupera configuracoes do banco de dados
        List<AtomDBConfig> dbConfigs = dbConfigRepository.findById_AtomdbId(atomdbId);
        AtomDBInterpreter dbInterpreter = new AtomDBInterpreter(dbConfigs);
        dbInterpreter.setAtomCipher(atomCipher);

        AnalyticDatabaseConfig analyticDatabaseConfig = new MonetdbAnalyticDatabaseConfig(
                dbInterpreter.getDatabase(),
                dbInterpreter.getUser(),
                dbInterpreter.getPassword(),
                dbInterpreter.getHost(),
                dbInterpreter.getPort());

        AnalyticDatabaseDAO databaseDAO = new MonetdbAnalyticDatabaseDAOImpl();

        AmazonS3 amazonS3Client = new AmazonS3Client(new EnvironmentVariableCredentialsProvider());
        amazonS3Client.setRegion(Region.getRegion(Regions.fromName(awsRegion)));

        if (log.isDebugEnabled()) {
            log.debug("s3EntryTemplate: {}", accountId);
            log.debug("s3EntryTemplate: {}", atomdbId);
            log.debug("s3EntryTemplate: {}", atomdbDataId);
            log.debug("s3EntryTemplate: {}", s3EntryTemplate);
        }

        String path = MessageFormat.format(s3EntryTemplate, accountId, atomdbId, atomdbDataId);
        if (log.isDebugEnabled()) {
            log.debug("path: {}", path);
        }

        final ListObjectsRequest listRequest = new ListObjectsRequest().withBucketName(bucketName).withPrefix(path);
        ObjectListing result;

        result = amazonS3Client.listObjects(listRequest);

        do {

            List<S3ObjectSummary> objectSummaries = result.getObjectSummaries().stream()
                    .filter(objectSummary -> objectSummary.getKey().contains("csv.gz"))
                    // inverte a ordem para garantir melhor consistencia e possiveis erros de valores em
                    // dimensao
                    .sorted(Comparator.comparing(S3ObjectSummary::getKey).reversed())
                    .collect(Collectors.toList());

            for (S3ObjectSummary objectSummary : objectSummaries) {
                String[] file = objectSummary.getKey().replaceAll(path + "\\/", "").split("\\/");
                String schema = "a" + accountId;
                String table = file[0].equals("fact") ? "s" + atomdbId : "s" + atomdbId + "_" + file[0];
                String tableWithSchema = schema + "." + table;

                S3Object s3Object = amazonS3Client.getObject(new GetObjectRequest(bucketName, objectSummary.getKey()));

                if (log.isDebugEnabled()) {
                    log.debug("objeto s3 carregado key:{}, size:{}", s3Object.getKey(), s3Object.getObjectMetadata().getContentLength());
                }
                // bulk load config
                Config bulkConfig = new Config();
                bulkConfig.add(MonetdbAnalyticDatabaseDAOImpl.DELIMITER_KEY, "|");
                bulkConfig.add(MonetdbAnalyticDatabaseDAOImpl.TABLE_KEY, tableWithSchema);
                databaseDAO.bulkLoad(bulkConfig, new GZIPInputStream(s3Object.getObjectContent()), analyticDatabaseConfig);
                s3Object.close();
                log.info("tabela {} carregado com sucesso", tableWithSchema);
            }

            result = amazonS3Client.listNextBatchOfObjects(result);

        } while (result.isTruncated() == true);

        log.info("carga de dados do start schema do atomDB:[{}] e entry:[{}] finalizada com sucesso", atomdbId, atomdbDataId);


        return RepeatStatus.FINISHED;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public void setAtomdbId(Long atomdbId) {
        this.atomdbId = atomdbId;
    }

    public void setAtomdbDataId(Long atomdbDataId) {
        this.atomdbDataId = atomdbDataId;
    }

    public void setAtomdbActionId(Long atomdbActionId) {
        this.atomdbActionId = atomdbActionId;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(accountId, "accountId must be set");
        Assert.notNull(atomdbId, "atomdbId must be set");
        Assert.notNull(atomdbDataId, "atomdbDataId must be set");
        Assert.notNull(atomdbActionId, "atomdbActionId must be set");
    }

    public void setAwsProfile(String awsProfile) {
        this.awsProfile = awsProfile;
    }

    public void setAwsRegion(String awsRegion) {
        this.awsRegion = awsRegion;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public void setS3EntryTemplate(String s3EntryTemplate) {
        this.s3EntryTemplate = s3EntryTemplate;
    }

    public void setAtomCipher(AtomCipher atomCipher) {
        this.atomCipher = atomCipher;
    }

    public void setDbConfigRepository(AtomDBConfigRepository dbConfigRepository) {
        this.dbConfigRepository = dbConfigRepository;
    }
}
