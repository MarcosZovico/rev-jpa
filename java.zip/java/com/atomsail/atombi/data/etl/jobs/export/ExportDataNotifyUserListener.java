package com.atomsail.atombi.data.etl.jobs.export;

import com.atomsail.atombi.data.etl.dto.AtomdbExportDataDTO;
import com.atomsail.atombi.data.etl.utils.JobParameterUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.text.MessageFormat;

import static com.atomsail.atombi.data.etl.jobs.export.ExportDataCsvJob.EXPORT_DATA_CSV_JOB;

public class ExportDataNotifyUserListener implements JobExecutionListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExportDataNotifyUserListener.class);

    @Value("${atombi.data.atomdb.export.export_done_template}")
    private String s3ExportTemplateDone;

    @Value("${atombi.data.atomdb.export.export_result_api}")
    private String exportResultApi;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private JobParameterUtil jobParameterUtil;

    @Override
    public void beforeJob(JobExecution jobExecution) {
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void afterJob(JobExecution jobExecution) {

        try {

            AtomdbExportDataDTO dto = jobParameterUtil.getParameter(jobExecution, "dto", AtomdbExportDataDTO.class);

            if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
                LOGGER.info("Job [{}] completado com sucesso", EXPORT_DATA_CSV_JOB);
                dto.setResult(Boolean.TRUE);
                dto.setS3Path(MessageFormat.format(s3ExportTemplateDone, dto.getAccountId(), dto.getCubeId()));
            } else {
                LOGGER.info("Job [{}] Falhou", EXPORT_DATA_CSV_JOB);
                dto.setResult(Boolean.FALSE);
            }

            HttpEntity<AtomdbExportDataDTO> entity = new HttpEntity<>(dto);
            LOGGER.info("fazendo requisicao para:{} ", exportResultApi);
            ResponseEntity<String> response = restTemplate.exchange(exportResultApi, HttpMethod.PUT, entity, String.class);

            LOGGER.info(response.getStatusCode().getReasonPhrase());
            LOGGER.info("{}",response.getStatusCodeValue());

        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
    }
}
