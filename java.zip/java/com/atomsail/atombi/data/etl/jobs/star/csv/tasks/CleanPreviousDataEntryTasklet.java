package com.atomsail.atombi.data.etl.jobs.star.csv.tasks;

import com.amazonaws.auth.EnvironmentVariableCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.Assert;

import java.text.MessageFormat;

public class CleanPreviousDataEntryTasklet implements Tasklet, InitializingBean {

    private static final Logger log = LoggerFactory.getLogger(CleanPreviousDataEntryTasklet.class);

    private Long accountId;
    private Long atomdbId;
    private Long atomdbDataId;
    private Long atomdbActionId;


    @Value("${aws.profile}")
    private String awsProfile;

    @Value("${aws.region}")
    private String awsRegion;


    @Value("${aws.bucket}")
    private String bucketName;

    @Value("${atombi.data.atomdb.entry.done_template_entry}")
    private String s3EntryTemplate;


    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {

        if (log.isDebugEnabled()) {
            log.debug("aws regiao configurada: {}", awsRegion);
            log.debug("aws profile configurada: {}", awsProfile);
        }

        AmazonS3 amazonS3Client = new AmazonS3Client(new EnvironmentVariableCredentialsProvider());
        amazonS3Client.setRegion(Region.getRegion(Regions.fromName(awsRegion)));

        String path = MessageFormat.format(s3EntryTemplate, accountId, atomdbId, atomdbDataId);
        if (log.isDebugEnabled()) {
            log.debug("caminho para remocao dos arquivos do atomdbData [{}]", atomdbDataId);
        }

        final ListObjectsRequest listRequest = new ListObjectsRequest().withBucketName(bucketName).withPrefix(path);
        ObjectListing result;

        do {
            result = amazonS3Client.listObjects(listRequest);

            for (S3ObjectSummary objectSummary : result.getObjectSummaries()) {
                amazonS3Client.deleteObject(bucketName, objectSummary.getKey());
                if (log.isDebugEnabled()) {
                    log.debug("objeto removido com key:{} [size = {}]", objectSummary.getKey(), objectSummary.getSize());
                }
            }

            if (result.getObjectSummaries().isEmpty()) {
                log.warn("nao ha arquivos para remover no caminho: {}", path);
            }

//            log.info("Next Continuation Token : " + result.getNextContinuationToken());
            result = amazonS3Client.listNextBatchOfObjects(result);
        } while (result.isTruncated() == true);

        amazonS3Client.deleteObject(bucketName, path);
        log.info("entry [{}] removida em {}", atomdbDataId, path);


        return RepeatStatus.FINISHED;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public void setAtomdbId(Long atomdbId) {
        this.atomdbId = atomdbId;
    }

    public void setAtomdbDataId(Long atomdbDataId) {
        this.atomdbDataId = atomdbDataId;
    }

    public void setAtomdbActionId(Long atomdbActionId) {
        this.atomdbActionId = atomdbActionId;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(accountId, "accountId must be set");
        Assert.notNull(atomdbId, "atomdbId must be set");
        Assert.notNull(atomdbDataId, "atomdbDataId must be set");
        Assert.notNull(atomdbActionId, "atomdbActionId must be set");
    }

    public void setAwsProfile(String awsProfile) {
        this.awsProfile = awsProfile;
    }

    public void setAwsRegion(String awsRegion) {
        this.awsRegion = awsRegion;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public void setS3EntryTemplate(String s3EntryTemplate) {
        this.s3EntryTemplate = s3EntryTemplate;
    }
}
