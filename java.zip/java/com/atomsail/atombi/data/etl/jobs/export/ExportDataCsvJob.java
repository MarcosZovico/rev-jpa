package com.atomsail.atombi.data.etl.jobs.export;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class ExportDataCsvJob {

    public static final String EXPORT_DATA_CSV_JOB = "EXPORT_DATA_CSV_JOB";

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    private PlatformTransactionManager transactionManager;

    @Bean
    public Tasklet exportDataCreateCsvTasklet() {
        return new ExportDataCreateCsvTasklet();
    }

    @Bean
    public Step exportDataCreateCsvStep() {
        return stepBuilderFactory.get("exportDataCreateCsvStep")
                                 .tasklet(exportDataCreateCsvTasklet())
                                 .repository(jobRepository)
                                 .transactionManager(transactionManager)
                                 .build();
    }

    @Bean
    public JobExecutionListener jobExportDataNotifyUserListener(){
        return new ExportDataNotifyUserListener();
    }


    @Bean
    public Job exportDataCSVJob() {
        return jobBuilderFactory.get(EXPORT_DATA_CSV_JOB)
                .listener(jobExportDataNotifyUserListener())
                .start(exportDataCreateCsvStep())
                .build();
    }


}
