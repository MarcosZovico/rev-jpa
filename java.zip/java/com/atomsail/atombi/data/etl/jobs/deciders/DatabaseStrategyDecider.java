package com.atomsail.atombi.data.etl.jobs.deciders;

import com.atomsail.atombi.data.etl.databases.DatabaseType;
import com.atomsail.atombi.data.etl.domain.AtomDBConfig;
import com.atomsail.atombi.data.etl.domain.AtomDBConfigPK;
import com.atomsail.atombi.data.etl.domain.AtomDBConfigSettingId;
import com.atomsail.atombi.data.etl.repositories.AtomDBConfigRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;
import org.springframework.beans.factory.annotation.Autowired;

public class DatabaseStrategyDecider implements JobExecutionDecider {

    public static final String STAR_SCHEMA_MONETDB = "STAR_SCHEMA_MONETDB";
    public static final String STAR_SCHEMA_MYSQL = "STAR_SCHEMA_MYSQL";
    public static final String STAR_SCHEMA_MARIADB = "STAR_SCHEMA_MARIADB";
    public static final String INVALID_DATABASE_TYPE = "INVALID_DATABASE_TYPE";
    private static final Logger log = LoggerFactory.getLogger(DatabaseStrategyDecider.class);


    @Autowired
    private AtomDBConfigRepository dbConfigRepository;

    @Override
    public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecution) {


        Long atomdbId = jobExecution.getJobParameters().getLong("atomdbId");

        AtomDBConfigPK id = new AtomDBConfigPK();
        id.setAtomdbId(atomdbId);
        id.setSettingId(AtomDBConfigSettingId.TYPE);

        log.info("decidindo tipo de banco {}", id);


        AtomDBConfig databaseTypeConfig = dbConfigRepository.findOne(id);

        if (log.isDebugEnabled()) {
            log.debug("config carregado {}", databaseTypeConfig);
        }

        DatabaseType databaseType = DatabaseType.valueOf(databaseTypeConfig.getConfigValue());


        switch (databaseType) {

            case MonetDb:
                log.info("utilizando estrategia {}", STAR_SCHEMA_MONETDB);
                return new FlowExecutionStatus(STAR_SCHEMA_MONETDB);
            case MySQL:
                log.info("utilizando estrategia {}", STAR_SCHEMA_MYSQL);
                return new FlowExecutionStatus(STAR_SCHEMA_MYSQL);
            case MariaDb:
                log.info("utilizando estrategia {}", STAR_SCHEMA_MARIADB);
                return new FlowExecutionStatus(STAR_SCHEMA_MARIADB);
            default:
                log.info("utilizando estrategia {}", INVALID_DATABASE_TYPE);
                return new FlowExecutionStatus(INVALID_DATABASE_TYPE);
        }

    }
}
