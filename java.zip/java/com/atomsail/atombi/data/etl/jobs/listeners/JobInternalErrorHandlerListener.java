package com.atomsail.atombi.data.etl.jobs.listeners;

import com.atomsail.atombi.data.etl.domain.AtomDBDataAttribute;
import com.atomsail.atombi.data.etl.domain.AtomDBDataAttributePK;
import com.atomsail.atombi.data.etl.domain.AtomDBDataAttributeType;
import com.atomsail.atombi.data.etl.repositories.AtomDBDataAttributesRepository;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class JobInternalErrorHandlerListener implements JobExecutionListener {

    private static final Logger log = LoggerFactory.getLogger(JobInternalErrorHandlerListener.class);

    @Autowired
    private AtomDBDataAttributesRepository attributesRepository;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        if (log.isDebugEnabled()) {
            log.debug("-- Job {} ERROR HANDLER com ID {}: INICIADO", jobExecution.getJobInstance().getJobName(), jobExecution.getJobId());
        }
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void afterJob(JobExecution jobExecution) {

        List<String> errorMsgs = new ArrayList<>();

        Date now = new Date();

        Long accountId = jobExecution.getJobParameters().getLong("accountId");
        Long atomdbId = jobExecution.getJobParameters().getLong("atomdbId");
        Long atomdbDataId = jobExecution.getJobParameters().getLong("atomdbDataId");
        Long atomdbActionId = jobExecution.getJobParameters().getLong("atomdbActionId");

        AtomDBDataAttributePK userAttributeId = new AtomDBDataAttributePK();
        userAttributeId.setAtomdbDataAttribute(AtomDBDataAttributeType.DATALOAD_ERROR);
        userAttributeId.setAtomdbDataId(atomdbDataId);
        AtomDBDataAttribute userErrorAttr = attributesRepository.findOne(userAttributeId);

        AtomDBDataAttributePK internalAttrId = new AtomDBDataAttributePK();
        internalAttrId.setAtomdbDataAttribute(AtomDBDataAttributeType.INTERNAL_ERROR);
        internalAttrId.setAtomdbDataId(atomdbDataId);
        AtomDBDataAttribute internalErrorAttr = attributesRepository.findOne(internalAttrId);


        if (jobExecution.getStatus() == BatchStatus.FAILED) {

            log.info("ACCOUNT-ID --> {}", accountId);
            log.info("ATOMDB-ID --> {}", atomdbId);
            log.info("ENTRY-ID --> {}", atomdbDataId);
            log.info("ACTION-ID --> {}", atomdbActionId);

            jobExecution.getAllFailureExceptions().stream().forEach(ex -> errorMsgs.add(ex.getMessage()));
            String userFinalMsg =
                    "Não foi possível encontrar o erro durante o processo de carga. Por favor entre em contato com o suporte " +
                    "pelo email: support@atomsail.com";
            String internalMsg = StringUtils.join(errorMsgs, "<br>");

            if (userErrorAttr == null) {
                userErrorAttr = createAtomDBDataAttribute(now, userAttributeId, userFinalMsg);
            } else {
                userErrorAttr.setValue(userFinalMsg);
                userErrorAttr.setUpdated(now);
            }

            if (internalErrorAttr == null) {
                internalErrorAttr = createAtomDBDataAttribute(now, internalAttrId, internalMsg);
            } else {
                internalErrorAttr.setValue(internalMsg);
                internalErrorAttr.setUpdated(now);
            }

            attributesRepository.save(userErrorAttr);
            log.info("Attribute data {} atualizado com {}", userAttributeId, userFinalMsg);

            attributesRepository.save(internalErrorAttr);
            log.info("Attribute data {} atualizado com {}", internalErrorAttr, internalMsg);

        }

        if (jobExecution.getStatus() == BatchStatus.COMPLETED && userErrorAttr != null) {
            attributesRepository.delete(userAttributeId);
            log.info("Attribute data {} removido com sucesso", userAttributeId);
        }

        if (jobExecution.getStatus() == BatchStatus.COMPLETED && internalErrorAttr != null) {
            attributesRepository.delete(internalErrorAttr);
            log.info("Attribute data {} removido com sucesso", internalAttrId);
        }

        if (log.isDebugEnabled()) {
            log.debug("-- Job {} ERROR HANDLER com ID {}: FINALIZADO", jobExecution.getJobInstance().getJobName(), jobExecution.getJobId());
        }
    }

    private AtomDBDataAttribute createAtomDBDataAttribute(Date now, AtomDBDataAttributePK userAttributeId, String internalMsg) {
        AtomDBDataAttribute internalErrorAttr;
        internalErrorAttr = new AtomDBDataAttribute();
        internalErrorAttr.setId(userAttributeId);
        internalErrorAttr.setValue(internalMsg);
        internalErrorAttr.setCreated(now);
        internalErrorAttr.setUpdated(now);
        internalErrorAttr.setMetadata("String");
        return internalErrorAttr;
    }
}
