package com.atomsail.atombi.data.etl.jobs.flat.csv;

public class ProcessFlatSchemaCsvJob {
}
