package com.atomsail.atombi.data.etl.jobs.listeners;

import com.atomsail.atombi.data.etl.domain.AtomDBAction;
import com.atomsail.atombi.data.etl.domain.AtomDBActionStatus;
import com.atomsail.atombi.data.etl.repositories.AtomDBActionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

public class AtomDBUpdateActionStatusListener implements JobExecutionListener {

    private static final Logger log = LoggerFactory.getLogger(AtomDBUpdateActionStatusListener.class);

    @Autowired
    private AtomDBActionRepository dbActionRepository;

    @Override
    public void beforeJob(JobExecution jobExecution) {
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void afterJob(JobExecution jobExecution) {

        Date now = new Date();

        Long atomdbActionId = jobExecution.getJobParameters().getLong("atomdbActionId");

        AtomDBAction atomDBAction = dbActionRepository.getOne(atomdbActionId);

        atomDBAction.setUpdated(now);

        if (jobExecution.getStatus() == BatchStatus.COMPLETED) {

            dbActionRepository.delete(atomdbActionId);
            log.info("DB Action [{}] removida como SUCESSO", atomdbActionId);

        } else if (jobExecution.getStatus() == BatchStatus.FAILED) {

            atomDBAction.setStatus(AtomDBActionStatus.ERROR);
            dbActionRepository.save(atomDBAction);

            log.info("DB Action [{}] atualizada para ERROR", atomdbActionId);
        }


    }
}
