package com.atomsail.atombi.data.etl.jobs.star.csv.jobs;

import com.atomsail.atombi.data.etl.jobs.deciders.DatabaseStrategyDecider;
import com.atomsail.atombi.data.etl.jobs.listeners.*;
import com.atomsail.atombi.data.etl.jobs.star.csv.tasks.CleanPreviousDataEntryTasklet;
import com.atomsail.atombi.data.etl.jobs.star.csv.tasks.files.CreateDimensionFilesFromS3Tasklet;
import com.atomsail.atombi.data.etl.jobs.star.csv.tasks.files.CreateFactFilesFromS3Tasklet;
import com.atomsail.atombi.data.etl.jobs.star.csv.tasks.insert.MariadbInsertDataFromS3Tasklet;
import com.atomsail.atombi.data.etl.jobs.star.csv.tasks.insert.MonetdbInsertDataFromS3Tasklet;
import com.atomsail.atombi.data.etl.jobs.star.csv.tasks.insert.MySQLInsertDataFromS3Tasklet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.job.flow.JobExecutionDecider;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.JobStepBuilder;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class StarSchemaInsertCsvJob {

    public static final String PROCESS_STAR_SCHEMA_CSV_JOB = "PROCESS_STAR_SCHEMA_CSV_JOB";
    public static final String CLEAN_ENTRY_JOB_NAME = "CLEAN_ENTRY_JOB_NAME";
    public static final String CREATE_FILES_JOB_NAME = "CREATE_FILES_JOB_NAME";
    public static final String POPUPATE_STAR_SCHEMA_JOB_NAME_MONETDB = "POPUPATE_STAR_SCHEMA_JOB_MONETDB";
    public static final String POPUPATE_STAR_SCHEMA_JOB_NAME_MYSQL = "POPUPATE_STAR_SCHEMA_JOB_MYSQL";
    public static final String POPUPATE_STAR_SCHEMA_JOB_NAME_MARIADB = "POPUPATE_STAR_SCHEMA_JOB_NAME_MARIADB";
    private static final Logger log = LoggerFactory.getLogger(StarSchemaInsertCsvJob.class);


    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    private TaskExecutor taskExecutor;

    @Autowired
    private JobLauncher jobLauncher;

    @Bean
    @StepScope
    public Tasklet cleanPreviousDataTask(@Value("#{jobParameters['accountId']}") Long accountId,
                                         @Value("#{jobParameters['atomdbId']}") Long atomdbId,
                                         @Value("#{jobParameters['atomdbDataId']}") Long atomdbDataId,
                                         @Value("#{jobParameters['atomdbActionId']}") Long atomdbActionId) {

        CleanPreviousDataEntryTasklet task = new CleanPreviousDataEntryTasklet();

        task.setAccountId(accountId);
        task.setAtomdbId(atomdbId);
        task.setAtomdbDataId(atomdbDataId);
        task.setAtomdbActionId(atomdbActionId);

        return task;
    }

    @Bean
    public Step cleanPreviousDataStep() {

        return stepBuilderFactory.get("cleanPreviousDataStep")
                .tasklet(cleanPreviousDataTask(
                        null,
                        null,
                        null,
                        null))
                .build();
    }

    @Bean
    @StepScope
    public Tasklet createFactTableFileStepTask(@Value("#{jobParameters['accountId']}") Long accountId,
                                               @Value("#{jobParameters['atomdbId']}") Long atomdbId,
                                               @Value("#{jobParameters['atomdbDataId']}") Long atomdbDataId,
                                               @Value("#{jobParameters['atomdbActionId']}") Long atomdbActionId) {

        CreateFactFilesFromS3Tasklet task = new CreateFactFilesFromS3Tasklet();

        task.setAccountId(accountId);
        task.setAtomdbId(atomdbId);
        task.setAtomdbDataId(atomdbDataId);
        task.setAtomdbActionId(atomdbActionId);

        return task;
    }

    @Bean
    public Step createFactTableFileStep() {

        return stepBuilderFactory.get("createFactTableFileStep")
                .tasklet(createFactTableFileStepTask(
                        null,
                        null,
                        null,
                        null))
                .build();
    }

    @Bean
    @StepScope
    public Tasklet createDimensionFileStepTask(@Value("#{jobParameters['accountId']}") Long accountId,
                                               @Value("#{jobParameters['atomdbId']}") Long atomdbId,
                                               @Value("#{jobParameters['atomdbDataId']}") Long atomdbDataId,
                                               @Value("#{jobParameters['atomdbActionId']}") Long atomdbActionId) {


        CreateDimensionFilesFromS3Tasklet task = new CreateDimensionFilesFromS3Tasklet();

        task.setAccountId(accountId);
        task.setAtomdbId(atomdbId);
        task.setAtomdbDataId(atomdbDataId);
        task.setAtomdbActionId(atomdbActionId);

        return task;

    }

    @Bean
    public Step createDimensionFileStep() {

        return stepBuilderFactory.get("createDimensionFileStep")
                .tasklet(createDimensionFileStepTask(null, null, null, null))
                .build();
    }

    @Bean
    @StepScope
    public Tasklet monetdbPopulateStarSchemaDatabaseStepTask(
            @Value("#{jobParameters['accountId']}") Long accountId,
            @Value("#{jobParameters['atomdbId']}") Long atomdbId,
            @Value("#{jobParameters['atomdbDataId']}") Long atomdbDataId,
            @Value("#{jobParameters['atomdbActionId']}") Long atomdbActionId

    ) {

        MonetdbInsertDataFromS3Tasklet task = new MonetdbInsertDataFromS3Tasklet();

        task.setAccountId(accountId);
        task.setAtomdbId(atomdbId);
        task.setAtomdbDataId(atomdbDataId);
        task.setAtomdbActionId(atomdbActionId);

        return task;
    }

    @Bean
    @StepScope
    public Tasklet mysqlPopulateStarSchemaDatabaseStepTask(
            @Value("#{jobParameters['accountId']}") Long accountId,
            @Value("#{jobParameters['atomdbId']}") Long atomdbId,
            @Value("#{jobParameters['atomdbDataId']}") Long atomdbDataId,
            @Value("#{jobParameters['atomdbActionId']}") Long atomdbActionId

    ) {

        MySQLInsertDataFromS3Tasklet task = new MySQLInsertDataFromS3Tasklet();

        task.setAccountId(accountId);
        task.setAtomdbId(atomdbId);
        task.setAtomdbDataId(atomdbDataId);
        task.setAtomdbActionId(atomdbActionId);

        return task;
    }

    @Bean
    @StepScope
    public Tasklet mariadbPopulateStarSchemaDatabaseStepTask(
            @Value("#{jobParameters['accountId']}") Long accountId,
            @Value("#{jobParameters['atomdbId']}") Long atomdbId,
            @Value("#{jobParameters['atomdbDataId']}") Long atomdbDataId,
            @Value("#{jobParameters['atomdbActionId']}") Long atomdbActionId

    ) {

        MariadbInsertDataFromS3Tasklet task = new MariadbInsertDataFromS3Tasklet();

        task.setAccountId(accountId);
        task.setAtomdbId(atomdbId);
        task.setAtomdbDataId(atomdbDataId);
        task.setAtomdbActionId(atomdbActionId);

        return task;
    }

    @Bean
    public JobExecutionListener jobUserErrorListener() {
        return new JobUserErrorHandlerListener();
    }

    @Bean
    public JobExecutionListener jobUpdateActionStatusListener() {
        return new AtomDBUpdateActionStatusListener();
    }

    @Bean
    public JobExecutionListener jobUpdateDataStatusListener() {
        return new AtomDBUpdateDataStatusListener();
    }

    @Bean
    public JobExecutionListener jobUpdateQuotaListener() {
        return new AtomDBUpdateQuotaListener();
    }

    @Bean
    public JobExecutionListener jobInternalErrorListener() {
        return new JobInternalErrorHandlerListener();
    }

    @Bean
    public JobExecutionListener jobRollbackListener() {
        return new JobRollbackListener();
    }

    @Bean
    public JobExecutionDecider databaseStrategyDecider() {
        return new DatabaseStrategyDecider();
    }

    @Bean
    public Step monetdbPopulateStarSchemaDatabaseStep() {

        return stepBuilderFactory.get("monetdbPopulateStarSchemaDatabaseStep")
                .tasklet(monetdbPopulateStarSchemaDatabaseStepTask(
                        null,
                        null,
                        null,
                        null))

                .build();
    }

    @Bean
    public Step mysqlPopulateStarSchemaDatabaseStep() {

        return stepBuilderFactory.get("mysqlPopulateStarSchemaDatabaseStep")
                .tasklet(mysqlPopulateStarSchemaDatabaseStepTask(
                        null,
                        null,
                        null,
                        null))

                .build();
    }

    @Bean
    public Step mariadbPopulateStarSchemaDatabaseStep() {

        return stepBuilderFactory.get("mariadbPopulateStarSchemaDatabaseStep")
                .tasklet(mariadbPopulateStarSchemaDatabaseStepTask(
                        null,
                        null,
                        null,
                        null))

                .build();
    }


    @Bean
    @Qualifier("createStarSchemaFileJob")
    public Job createStarSchemaFileJob(JobRepository jobRepository, PlatformTransactionManager transactionManager) {

        Step removeOldFilesJobStep = new JobStepBuilder(new StepBuilder(CLEAN_ENTRY_JOB_NAME + "_step"))
                .job(removeOldFiles())
                .launcher(jobLauncher)
                .repository(jobRepository)
                .transactionManager(transactionManager)
                .build();

        Step createFilesJobStep = new JobStepBuilder(new StepBuilder(CREATE_FILES_JOB_NAME + "_step"))
                .job(createFilesJob())
                .launcher(jobLauncher)
                .repository(jobRepository)
                .transactionManager(transactionManager)
                .build();

        Step monetebPopulateStarSchemaJobStep = new JobStepBuilder(new StepBuilder(POPUPATE_STAR_SCHEMA_JOB_NAME_MONETDB + "_step"))
                .job(monetdbPopulateStarSchemaJob())
                .launcher(jobLauncher)
                .repository(jobRepository)
                .transactionManager(transactionManager)
                .build();

        Step mysqlPopulateStarSchemaJobStep = new JobStepBuilder(new StepBuilder(POPUPATE_STAR_SCHEMA_JOB_NAME_MYSQL + "_step"))
                .job(mysqlPopulateStarSchemaJob())
                .launcher(jobLauncher)
                .repository(jobRepository)
                .transactionManager(transactionManager)
                .build();

        Step mariadbPopulateStarSchemaJobStep = new JobStepBuilder(new StepBuilder(POPUPATE_STAR_SCHEMA_JOB_NAME_MARIADB + "_step"))
                .job(mariaPopulateStarSchemaJob())
                .launcher(jobLauncher)
                .repository(jobRepository)
                .transactionManager(transactionManager)
                .build();


        return jobBuilderFactory.get(PROCESS_STAR_SCHEMA_CSV_JOB)

                .listener(jobRollbackListener())
                .listener(jobUpdateQuotaListener())
                .listener(jobUpdateActionStatusListener())
                .listener(jobUpdateDataStatusListener())
                .start(removeOldFilesJobStep)
                .next(createFilesJobStep)
                .next(databaseStrategyDecider()).on(DatabaseStrategyDecider.STAR_SCHEMA_MONETDB).to(monetebPopulateStarSchemaJobStep)
                .from(databaseStrategyDecider()).on(DatabaseStrategyDecider.STAR_SCHEMA_MYSQL).to(mysqlPopulateStarSchemaJobStep)
                .from(databaseStrategyDecider()).on(DatabaseStrategyDecider.STAR_SCHEMA_MARIADB).to(mariadbPopulateStarSchemaJobStep)
                .from(databaseStrategyDecider()).on(DatabaseStrategyDecider.INVALID_DATABASE_TYPE).fail()
                .end()
                .build();
    }


    @Bean
    public Job removeOldFiles() {

        Flow cleanFilesFlow = new FlowBuilder<Flow>("removeOldFiles").start(cleanPreviousDataStep()).build();

        return jobBuilderFactory.get(CLEAN_ENTRY_JOB_NAME)
                .listener(jobInternalErrorListener())
                .start(cleanFilesFlow)
                .end()
                .build();
    }

    @Bean
    public Job createFilesJob() {

        Flow factFlow = new FlowBuilder<Flow>("factFilesFlow").start(createFactTableFileStep()).build();
        Flow dimensionFlow = new FlowBuilder<Flow>("dimensionFilesFlow").start(createDimensionFileStep()).build();

        return jobBuilderFactory.get(CREATE_FILES_JOB_NAME)
                .listener(jobUserErrorListener())
                .start(factFlow)
                .split(taskExecutor).add(dimensionFlow)
                .end()
                .build();
    }

    @Bean
    public Job monetdbPopulateStarSchemaJob() {

        Flow monetdbPopulateStarSchemaJob = new FlowBuilder<Flow>("monetdbPopulateStarSchemaJob").start(monetdbPopulateStarSchemaDatabaseStep()).build();

        return jobBuilderFactory.get(POPUPATE_STAR_SCHEMA_JOB_NAME_MONETDB)
                .listener(jobInternalErrorListener())
                .start(monetdbPopulateStarSchemaJob)
                .end()
                .build();
    }

    @Bean
    public Job mysqlPopulateStarSchemaJob() {

        Flow mysqlPopulateStarSchemaJob = new FlowBuilder<Flow>("mysqlPopulateStarSchemaJob").start(mysqlPopulateStarSchemaDatabaseStep()).build();

        return jobBuilderFactory.get(POPUPATE_STAR_SCHEMA_JOB_NAME_MYSQL)
                .listener(jobInternalErrorListener())
                .start(mysqlPopulateStarSchemaJob)
                .end()
                .build();
    }

    @Bean
    public Job mariaPopulateStarSchemaJob() {

        Flow mariadbPopulateStarSchemaJob = new FlowBuilder<Flow>("mariadbPopulateStarSchemaJob").start(mariadbPopulateStarSchemaDatabaseStep()).build();

        return jobBuilderFactory.get(POPUPATE_STAR_SCHEMA_JOB_NAME_MARIADB)
                .listener(jobInternalErrorListener())
                .start(mariadbPopulateStarSchemaJob)
                .end()
                .build();
    }


}
