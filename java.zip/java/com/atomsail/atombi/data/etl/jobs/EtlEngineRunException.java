package com.atomsail.atombi.data.etl.jobs;

public class EtlEngineRunException extends Exception {

    public EtlEngineRunException() {
    }

    public EtlEngineRunException(String message) {
        super(message);
    }

    public EtlEngineRunException(String message, Throwable cause) {
        super(message, cause);
    }

    public EtlEngineRunException(Throwable cause) {
        super(cause);
    }

    public EtlEngineRunException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
