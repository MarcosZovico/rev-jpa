package com.atomsail.atombi.data.etl.jobs.star.csv;

public class SparkSqlFormats {

    public static final String TIMESTAMP_FORMAT = "yyyy-MM-dd HH:mm:ss";
}
