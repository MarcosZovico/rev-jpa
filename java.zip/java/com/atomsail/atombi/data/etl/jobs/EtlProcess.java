package com.atomsail.atombi.data.etl.jobs;

public interface EtlProcess {

    /**
     * Executa processo de transformacao para arquivo CSV
     * @param accountId Codigo da conta
     * @param atomdbId Codigo do AtomDB
     * @param atomdbDataId Codigo da carga
     * @param dbActionId Codigo da acao no banco de dados
     * @throws EtlEngineRunException
     */
    void execute(Long accountId, Long atomdbId, Long atomdbDataId, Long dbActionId) throws EtlEngineRunException;
}
