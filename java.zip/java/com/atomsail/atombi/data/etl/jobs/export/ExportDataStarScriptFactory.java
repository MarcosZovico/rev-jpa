package com.atomsail.atombi.data.etl.jobs.export;


import com.atomsail.atombi.data.etl.domain.AtomDBField;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import static com.atomsail.atombi.data.etl.metadata.FieldTypes.*;


/**
 * Gera o script para exportar todos os dados de um cubo, o script é gerado com
 * os fields do cubo que representam as colunas do arquivo original.
 * 
 * @author Marcos Souza
 *
 */
public class ExportDataStarScriptFactory {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExportDataStarScriptFactory.class);

	private static final String COLUMN = "s{0,number,#}_{1}";
	private static final String COLUMN_VALUE = "s{0,number,#}_{1}_value";
    private static final String AS_VALUE = " AS {0}";

	private static final String COLUMN_ID = "s{0,number,#}_{1}_id";
	private static final String COLUMN_TIME_ID = "s{0,number,#}_{1}_time_id";

	private List<AtomDBField> fields;
	private Long accountId;
	private Long cubeId;

	public ExportDataStarScriptFactory(List<AtomDBField> fields, Long accountId, Long cubeId){
		this.fields = fields;
		this.accountId = accountId;
		this.cubeId = cubeId;
	}

	public String getSparkScript() {

		LOGGER.info("Criando Script para exportar dados ");

		String fact = MessageFormat.format("a{0,number,#}.s{1,number,#}", accountId, cubeId);
		String factAlias = MessageFormat.format("s{0,number,#}", cubeId);
		String schema = MessageFormat.format("a{0,number,#}", accountId);
		String timeDimension = MessageFormat.format("{0}.time_dimension", schema);

		List<String> joinList = new ArrayList<>();

		for (AtomDBField field : fields) {

			StringBuilder join = new StringBuilder();
			String column = MessageFormat.format("field{0,number,#}", field.getFieldId());

			String name = field.getName().replaceAll("\\s","_")
			 						     .replaceAll("/","_");

			switch (field.getType()){
				case TEXT:
					join.append(column);
					join.append(".");
					join.append(MessageFormat.format(COLUMN_VALUE, cubeId, column));
					join.append(MessageFormat.format(AS_VALUE, name));

					joinList.add(join.toString());
					break;
				case DATE:
					join.append(MessageFormat.format("{0}.time_datetime", column));
					join.append(MessageFormat.format(AS_VALUE, name));

					joinList.add(join.toString());
					break;
				case NUMBER:
					join.append(factAlias);
					join.append(".");
					join.append(MessageFormat.format(COLUMN, cubeId, column));
					join.append(MessageFormat.format(AS_VALUE, name));

					joinList.add(join.toString());
					break;
			}
		}

		StringBuilder exportScript = new StringBuilder();

		exportScript.append(" ( SELECT ");
		exportScript.append(StringUtils.join(joinList, ","));
		exportScript.append(" FROM ");
		exportScript.append(fact);
		exportScript.append(" ");
		exportScript.append(factAlias);

		// cria os join
		for (AtomDBField field : fields) {

			String column = MessageFormat.format("field{0,number,#}", field.getFieldId());

			switch (field.getType()){
				case TEXT:
					exportScript.append(" LEFT JOIN ");
					exportScript.append(schema);
					exportScript.append(".");
					exportScript.append(MessageFormat.format(COLUMN, cubeId, column)).append(" ");
					exportScript.append(column);
					exportScript.append(" ON (");
					exportScript.append(factAlias);
					exportScript.append(".");
					exportScript.append(MessageFormat.format(COLUMN_ID, cubeId, column));
					exportScript.append(" = ");
					exportScript.append(column);
					exportScript.append(".");
					exportScript.append(MessageFormat.format(COLUMN_ID, cubeId, column));
					exportScript.append(")");
					break;
				case DATE:
					exportScript.append(" LEFT JOIN ");
					exportScript.append(timeDimension);
					exportScript.append(" ");
					exportScript.append(column);
					exportScript.append(" ON (");
					exportScript.append(factAlias);
					exportScript.append(".");
					exportScript.append(MessageFormat.format(COLUMN_TIME_ID, cubeId, column));
					exportScript.append(" = ");
					exportScript.append(MessageFormat.format("{0}.time_id", column));
					exportScript.append(")");
					break;
			}
		}

		exportScript.append(MessageFormat.format(" ) s{0,number,#}_tmp", cubeId));

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Script gerado [{}]", exportScript.toString());
		}

		return exportScript.toString();

	}

}
