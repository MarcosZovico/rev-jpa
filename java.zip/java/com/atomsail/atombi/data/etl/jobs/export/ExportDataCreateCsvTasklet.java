package com.atomsail.atombi.data.etl.jobs.export;

import com.atomsail.atombi.data.etl.cipher.AtomCipher;
import com.atomsail.atombi.data.etl.domain.AtomDBConfig;
import com.atomsail.atombi.data.etl.domain.AtomDBField;
import com.atomsail.atombi.data.etl.dto.AtomdbExportDataDTO;
import com.atomsail.atombi.data.etl.repositories.AtomDBConfigRepository;
import com.atomsail.atombi.data.etl.repositories.AtomDBFieldRepository;
import com.atomsail.atombi.data.etl.utils.AtomDBInterpreter;
import com.atomsail.atombi.data.etl.utils.JobParameterUtil;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.text.MessageFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.atomsail.atombi.data.etl.metadata.FieldTypes.*;

public class ExportDataCreateCsvTasklet implements Tasklet {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExportDataCreateCsvTasklet.class);
    private static final List<String> FIELD_TYPES = Collections.unmodifiableList(Arrays.asList(TEXT, DATE, NUMBER));

    @Value("${atombi.data.atomdb.export.export_template}")
    private String s3OutputTemplate;

    @Autowired
    private SparkSession sparkSession;

    @Autowired
    private AtomDBFieldRepository fieldRepository;

    @Autowired
    private JobParameterUtil jobParameterUtil;

    @Autowired
    private AtomCipher atomCipher;

    @Autowired
    private AtomDBConfigRepository dbConfigRepository;

    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {

        try {

            AtomdbExportDataDTO dto = jobParameterUtil.getParameter(chunkContext, "dto", AtomdbExportDataDTO.class);

            LOGGER.info("Criando arquivo csv do Atomdb [s{}] ", dto.getCubeId());

            List<AtomDBField> fields = fieldRepository.findByAtomDB_AtomdbId(dto.getCubeId());
            List<AtomDBConfig> dbConfigs = dbConfigRepository.findById_AtomdbId(dto.getCubeId());
            String outputFile = MessageFormat.format(s3OutputTemplate, dto.getAccountId(), dto.getCubeId());

            // pega configurações do banco de dados
            AtomDBInterpreter atomDBConfig = new AtomDBInterpreter(dbConfigs);
            atomDBConfig.setAtomCipher(atomCipher);

            List<AtomDBField> sortedFields = fields.stream()
                                                   .filter(atomDBField -> FIELD_TYPES.contains(atomDBField.getType()))
                                                   .sorted(Comparator.comparing(AtomDBField::getOrder))
                                                   .collect(Collectors.toList());

            ExportDataStarScriptFactory scriptFactory = new ExportDataStarScriptFactory(sortedFields, dto.getAccountId(), dto.getCubeId());

            List<StructField> structFields = new ArrayList<>();
            sortedFields.forEach(field -> {
                StructField structField = new StructField(field.getFieldName(), DataTypes.StringType, true, Metadata.empty());
                structFields.add(structField);
            });

            StructType customSchema = new StructType(structFields.toArray(new StructField[sortedFields.size()]));

            LOGGER.info("Executando query na banco para exportar os dados");

            Dataset<Row> dataSet = sparkSession.read()
                                               .format("jdbc")
                                               .option("header", "true")
                                               .option("url", atomDBConfig.getJdbcUrlSpark())
                                               .option("dbtable", scriptFactory.getSparkScript())
                                               .option("user", atomDBConfig.getUser())
                                               .option("password", atomDBConfig.getPassword())
                                               .load();

            LOGGER.info("Salando arquivo no S3");

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Salvando arquivo no s3 em: {}", outputFile);
                dataSet.show(10,false);
            }
            dataSet.write()
                         .format("com.databricks.spark.csv")
                         .option("header", true)
                         .mode("overwrite") // sobrescreve (remove e cria nova) a pasta no s3 caso já exista
                         .option("delimiter", "|")
                         .option("codec", "org.apache.hadoop.io.compress.GzipCodec")
                         .csv(outputFile);

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Arquivo salvo em: [{}]", outputFile);
            }

            LOGGER.info("Arquivo CSV salvo do AtomDB : [s{}]", dto.getCubeId());

            return RepeatStatus.FINISHED;

        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            throw new AtomDBExportException(ExceptionUtils.getRootCauseMessage(e));
        }
    }

}
