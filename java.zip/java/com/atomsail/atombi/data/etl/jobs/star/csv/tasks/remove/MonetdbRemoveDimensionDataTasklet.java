package com.atomsail.atombi.data.etl.jobs.star.csv.tasks.remove;

import com.atomsail.atombi.data.etl.cipher.AtomCipher;
import com.atomsail.atombi.data.etl.domain.AtomDBConfig;
import com.atomsail.atombi.data.etl.domain.AtomDBField;
import com.atomsail.atombi.data.etl.metadata.FieldTypes;
import com.atomsail.atombi.data.etl.repositories.AtomDBConfigRepository;
import com.atomsail.atombi.data.etl.repositories.AtomDBFieldRepository;
import com.atomsail.atombi.data.etl.utils.AtomDBInterpreter;
import com.atomsail.atombi.data.etl.utils.AtomDBSqlUtils;
import com.atomsail.atombi.databases.AnalyticDatabaseConfig;
import com.atomsail.atombi.databases.dao.AnalyticDatabaseDAO;
import com.atomsail.atombi.databases.monetdb.dao.MonetdbAnalyticDatabaseDAOImpl;
import com.atomsail.atombi.databases.monetdb.db.MonetdbAnalyticDatabaseConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;

public class MonetdbRemoveDimensionDataTasklet implements Tasklet, InitializingBean {

    private static final Logger log = LoggerFactory.getLogger(MonetdbRemoveDimensionDataTasklet.class);

    private Long accountId;
    private Long atomdbId;
    private Long atomdbDataId;
    private Long atomdbActionId;

    @Autowired
    private AtomDBConfigRepository dbConfigRepository;

    @Autowired
    private AtomCipher atomCipher;


    @Autowired
    private AtomDBFieldRepository fieldRepository;


    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {

        List<AtomDBField> textFields = fieldRepository.findByAtomDB_AtomdbIdAndTypeOrderByOrder(atomdbId, FieldTypes.TEXT);


        // recupera configuracoes do banco de dados
        List<AtomDBConfig> dbConfigs = dbConfigRepository.findById_AtomdbId(atomdbId);
        AtomDBInterpreter dbInterpreter = new AtomDBInterpreter(dbConfigs);
        dbInterpreter.setAtomCipher(atomCipher);

        AnalyticDatabaseConfig analyticDatabaseConfig = new MonetdbAnalyticDatabaseConfig(
                dbInterpreter.getDatabase(),
                dbInterpreter.getUser(),
                dbInterpreter.getPassword(),
                dbInterpreter.getHost(),
                dbInterpreter.getPort());

        AnalyticDatabaseDAO databaseDAO = new MonetdbAnalyticDatabaseDAOImpl();
        List<String> statements = new ArrayList<>();


        for (AtomDBField textField : textFields) {

            statements.add(AtomDBSqlUtils.cleanDimension(accountId, atomdbId, textField.getFieldId()));

        }

        databaseDAO.executeStatement(statements, analyticDatabaseConfig);

        log.info("limpeza de dimensoes finalizada com sucesso para atomdb=[{}]", atomdbId);
        return RepeatStatus.FINISHED;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public void setAtomdbId(Long atomdbId) {
        this.atomdbId = atomdbId;
    }

    public void setAtomdbDataId(Long atomdbDataId) {
        this.atomdbDataId = atomdbDataId;
    }

    public void setAtomdbActionId(Long atomdbActionId) {
        this.atomdbActionId = atomdbActionId;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(accountId, "accountId must be set");
        Assert.notNull(atomdbId, "atomdbId must be set");
        Assert.notNull(atomdbDataId, "atomdbDataId must be set");
        Assert.notNull(atomdbActionId, "atomdbActionId must be set");
    }
}
