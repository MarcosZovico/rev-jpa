package com.atomsail.atombi.data.etl.jobs.star.csv.tasks.files;

import com.atomsail.atombi.data.etl.databases.DatabaseType;
import com.atomsail.atombi.data.etl.domain.*;
import com.atomsail.atombi.data.etl.dto.FieldInputMapDTO;
import com.atomsail.atombi.data.etl.jobs.star.csv.SparkSqlFieldTemplates;
import com.atomsail.atombi.data.etl.jobs.star.csv.SparkSqlFormats;
import com.atomsail.atombi.data.etl.jobs.star.csv.tasks.MalFormatedFileException;
import com.atomsail.atombi.data.etl.metadata.FieldTypes;
import com.atomsail.atombi.data.etl.repositories.AtomDBConfigRepository;
import com.atomsail.atombi.data.etl.repositories.AtomDBDataAttributesRepository;
import com.atomsail.atombi.data.etl.repositories.AtomDBFieldRepository;
import com.atomsail.atombi.data.etl.utils.AtomdbDataAttributeUtil;
import com.atomsail.atombi.data.etl.utils.FromToMapUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.hibernate.engine.jdbc.internal.BasicFormatterImpl;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.Assert;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class CreateFactFilesFromS3Tasklet implements Tasklet, InitializingBean {


    private static final Logger log = LoggerFactory.getLogger(CreateFactFilesFromS3Tasklet.class);

    private Long accountId;
    private Long atomdbId;
    private Long atomdbDataId;
    private Long atomdbActionId;

    @Value("${atombi.data.atomdb.entry.max_rows_per_file:10000}")
    private String maxRowsPerFile;

    @Value("${atombi.data.atomdb.entry.pending_template}")
    private String s3InputTemplate;


    @Value("${atombi.data.atomdb.entry.done_template_fact}")
    private String s3OutputTemplate;

    @Autowired
    private SparkSession sparkSession;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private AtomDBFieldRepository fieldRepository;

    @Autowired
    private AtomDBDataAttributesRepository attributesRepository;

    @Autowired
    private AtomDBConfigRepository dbConfigRepository;


    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {


        log.info("START: criando arquivos da tabela de fatos para entrada de carga: [{}]", atomdbDataId);
        try {


            // busca no banco de dados as informações necessárias para processar o arquivo
            List<AtomDBField> fields = fieldRepository.findByAtomDB_AtomdbId(atomdbId);
            List<AtomDBDataAttribute> attributes = attributesRepository.findAtomdbDataAttributeById_AtomdbDataId(atomdbDataId);

            AtomDBConfig dbTypeConfig = dbConfigRepository.findById(new AtomDBConfigPK(atomdbId, AtomDBConfigSettingId.TYPE));
            DatabaseType databaseType = DatabaseType.valueOf(dbTypeConfig.getConfigValue());

            // recupera atributos necessarios para o processo de carga
            Optional<AtomDBDataAttribute> header = AtomdbDataAttributeUtil.get(AtomDBDataAttributeType.HAS_HEADER, attributes);
            Optional<AtomDBDataAttribute> delimiter = AtomdbDataAttributeUtil.get(AtomDBDataAttributeType.DELIMITER, attributes);
            Optional<AtomDBDataAttribute> fromMap = AtomdbDataAttributeUtil.get(AtomDBDataAttributeType.FROM_TO_MAP, attributes);
            Optional<AtomDBDataAttribute> s3InputFile = AtomdbDataAttributeUtil.get(AtomDBDataAttributeType.S3_URL, attributes);
            List<FieldInputMapDTO> mappedFields = objectMapper.readValue(fromMap.get().getValue(), new TypeReference<List<FieldInputMapDTO>>() {
            });

            // nome da tabela temporária criada no spark para leitura das informações do CSV
            String sparkTempView = "s" + atomdbId + "_entry" + atomdbDataId;


            // caminhos de entrada e saida dos arquivos
            String inputFile = MessageFormat.format(s3InputTemplate, s3InputFile.get().getValue());
            String outputFile = MessageFormat.format(s3OutputTemplate, accountId, atomdbId, atomdbDataId);
            if (log.isDebugEnabled()) {
                log.debug("customer s3 input file: {}", inputFile);
                log.debug("customer s3 output file: {}", outputFile);
            }

            // filtra os campos que devem ser processados e os coloca em ordem
            List<AtomDBField> sortedFields = fields
                    .stream()
                    .filter(atomDBField ->
                            atomDBField.getType().equals(FieldTypes.TEXT) ||
                                    atomDBField.getType().equals(FieldTypes.NUMBER) ||
                                    atomDBField.getType().equals(FieldTypes.DATE)
                    ).sorted(Comparator.comparing(AtomDBField::getOrder)).collect(Collectors.toList());

            // logging
            if (log.isDebugEnabled()) {
                sortedFields.stream().forEach(field -> log.debug("campo: {}", field));
            }

            // cria estrutura de campos com o tamanho encontrado no banco de dados
            List<StructField> structFields = new ArrayList<>();

            // adiciona o select na base princial da query
            StringBuilder sparkSql = new StringBuilder();
            sparkSql.append("select ");

            List<String> queryFields = new ArrayList<>();

            queryFields.add(atomdbDataId + " as s" + atomdbId + "_cube_data_id");

            // cria struct dos campos
            for (AtomDBField field : sortedFields){
                // CAMPOS do tipo TEXT
                if (field.getType().equals(FieldTypes.TEXT)) {

                    // adiciona campo à estrutura do spark
                    structFields.add(new StructField(field.getFieldName(), DataTypes.StringType, true, Metadata.empty()));

                    // adiciona item a lista do select
                    if (databaseType == DatabaseType.MariaDb){
                        log.info("Adicionando tratamento de caracteres especiais para o AtomDB s{}", atomdbId);
                        queryFields.add(SparkSqlFieldTemplates.getTextMd5FieldNormalizedAscii(field.getFieldName(), field.getName(), Boolean.TRUE));
                    } else {
                        queryFields.add(SparkSqlFieldTemplates.getTextMd5Field(field.getFieldName(), field.getSourceFieldNameId()).replaceAll("''", "'"));
                    }

                } else if (field.getType().equals(FieldTypes.NUMBER)) {

                    // adiciona campo à estrutura do spark
                    structFields.add(new StructField(field.getFieldName(), DataTypes.StringType, true, Metadata.empty()));


                    Optional<FieldInputMapDTO> decimalSymbol = FromToMapUtil.getFieldByOrder(mappedFields, field.getOrder());

                    // adiciona item a lista do select
                    String numberField = MessageFormat.format(SparkSqlFieldTemplates.NUMBER_FIELD_TEMPLATE,
                            field.getFieldName(), // field column
                            decimalSymbol.get().getDecimalSymbol(), // decimal symbol
                            decimalSymbol.get().getName(), // nome do campo de entrada
                            field.getSourceFieldNameId()// alias
                    );

                    if (log.isDebugEnabled()) {
                        log.debug("numberField {} = {}", field.getSourceFieldName(), numberField);
                    }
                    queryFields.add(numberField);

                } else if (field.getType().equals(FieldTypes.DATE)) {

                    // adiciona item a lista do select
                    structFields.add(new StructField(field.getFieldName(), DataTypes.StringType, true, Metadata.empty()));

                    // adiciona item a lista do select e adiciona formato ao campo para fazer o parse informado pelo usuario
                    Optional<FieldInputMapDTO> dateFormat = FromToMapUtil.getFieldByOrder(mappedFields, field.getOrder());
                    String toDate = MessageFormat.format(SparkSqlFieldTemplates.TIME_ID_FIELD_TEMPLATE,
                            field.getFieldName(),
                            dateFormat.get().getFormat(),
                            dateFormat.get().getName(), // nome do campo de entrada
                            field.getSourceFieldName() + "_time_id");
                    queryFields.add(toDate);


                }
            }

            // adiciona campo com data de criacao do registro
            queryFields.add("'" + DateTime.now().toString(SparkSqlFormats.TIMESTAMP_FORMAT) + "' as current_time");

            // concatena tudo com uma unica string
            String queryBody = String.join(", ", queryFields);

            // adiciona from ao sql
            sparkSql.append(queryBody).append(" ").append(" from " + sparkTempView);

            if (log.isDebugEnabled()) {
                log.debug("sql gerado: \n {}", new BasicFormatterImpl().format(sparkSql.toString()));
            }

            // associa a estrutura criada para fazer a consulta com um schema personalizado do arquivo csv
            StructType customSchema = new StructType(structFields.toArray(new StructField[structFields.size()]));


            // cria leitor do arquivo csv salvo no AWS S3
            Dataset<Row> dataSet = sparkSession
                    .read()
                    .format("com.databricks.spark.csv")
                    .option("header", header.get().getValue())
                    .option("codec", "org.apache.hadoop.io.compress.GzipCodec")
                    .option("delimiter", delimiter.get().getValue())
                    .option("mode", "failFast")
                    .option("quote", "\"")
                    .schema(customSchema)
                    .csv(inputFile);

            dataSet.printSchema();

            // cria tabela temporária no spark para leitura do arquivo via SQL
            dataSet.createOrReplaceTempView(sparkTempView);
            if (log.isDebugEnabled()) {
                log.debug("criado tabela temporaria no spark com nome: [{}]", sparkTempView);
            }

            Dataset<Row> csvSet = sparkSession.sqlContext().sql(sparkSql.toString());

            if (log.isDebugEnabled()) {
                csvSet.show(100,false);
            }
            // executa parse do arquivo e gera arquivo final
            csvSet.write()
                  .format("com.databricks.spark.csv")
                  .mode("overwrite") // sobrescreve (remove e cria nova) a pasta no s3 caso já exista
                  .option("delimiter", "|")
                  .option("maxRecordsPerFile", maxRowsPerFile)
                  .option("codec", "org.apache.hadoop.io.compress.GzipCodec")
                  .csv(outputFile);

            if (log.isDebugEnabled()) {
                log.debug("arquivo salvo em: [{}]", outputFile);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new MalFormatedFileException(ExceptionUtils.getRootCauseMessage(e));
        }

        log.info("END: criando arquivos da tabela de fatos para entrada de carga: [{}]", atomdbDataId);

        return RepeatStatus.FINISHED;

    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public void setAtomdbId(Long atomdbId) {
        this.atomdbId = atomdbId;
    }

    public void setAtomdbDataId(Long atomdbDataId) {
        this.atomdbDataId = atomdbDataId;
    }

    public void setAtomdbActionId(Long atomdbActionId) {
        this.atomdbActionId = atomdbActionId;
    }

    public void setMaxRowsPerFile(String maxRowsPerFile) {
        this.maxRowsPerFile = maxRowsPerFile;
    }

    public void setS3InputTemplate(String s3InputTemplate) {
        this.s3InputTemplate = s3InputTemplate;
    }

    public void setS3OutputTemplate(String s3OutputTemplate) {
        this.s3OutputTemplate = s3OutputTemplate;
    }


    public void setSparkSession(SparkSession sparkSession) {
        this.sparkSession = sparkSession;
    }

    public void setObjectMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public void setFieldRepository(AtomDBFieldRepository fieldRepository) {
        this.fieldRepository = fieldRepository;
    }

    public void setAttributesRepository(AtomDBDataAttributesRepository attributesRepository) {
        this.attributesRepository = attributesRepository;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(accountId, "accountId must be set");
        Assert.notNull(atomdbId, "atomdbId must be set");
        Assert.notNull(atomdbDataId, "atomdbDataId must be set");
        Assert.notNull(atomdbActionId, "atomdbActionId must be set");
    }
}
