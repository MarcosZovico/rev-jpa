package com.atomsail.atombi.data.etl.jobs.listeners;

public class JobErrorMessageHandler {
    public static String get(String message) {

        if (message.indexOf("Malformed CSV record") >= 0) {
            return "Arquivo CSV mal formatadado. Existe uma linha inconsistente, impedindo seu processamento. " +
                    "Revise o arquivo enviado ou entre em contato conosco para ajudá-lo. " +
                    "DICA: Utilize o site: https://csvlint.io/ para validar o arquivo.";
        } else {
            return message;
        }


    }
}
