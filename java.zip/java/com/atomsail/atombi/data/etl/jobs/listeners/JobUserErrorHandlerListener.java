package com.atomsail.atombi.data.etl.jobs.listeners;

import com.atomsail.atombi.data.etl.domain.AtomDBDataAttribute;
import com.atomsail.atombi.data.etl.domain.AtomDBDataAttributePK;
import com.atomsail.atombi.data.etl.domain.AtomDBDataAttributeType;
import com.atomsail.atombi.data.etl.repositories.AtomDBDataAttributesRepository;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class JobUserErrorHandlerListener implements JobExecutionListener {

    private static final Logger log = LoggerFactory.getLogger(JobUserErrorHandlerListener.class);

    @Autowired
    private AtomDBDataAttributesRepository attributesRepository;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        if (log.isDebugEnabled()) {
            log.debug("-- Job {} ERROR HANDLER com ID {}: INICIADO", jobExecution.getJobInstance().getJobName(), jobExecution.getJobId());
        }
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void afterJob(JobExecution jobExecution) {

        List<String> errorMsgs = new ArrayList<>();

        Date now = new Date();

        Long accountId = jobExecution.getJobParameters().getLong("accountId");
        Long atomdbId = jobExecution.getJobParameters().getLong("atomdbId");
        Long atomdbDataId = jobExecution.getJobParameters().getLong("atomdbDataId");
        Long atomdbActionId = jobExecution.getJobParameters().getLong("atomdbActionId");

        AtomDBDataAttributePK attributeId = new AtomDBDataAttributePK();
        attributeId.setAtomdbDataAttribute(AtomDBDataAttributeType.DATALOAD_ERROR);
        attributeId.setAtomdbDataId(atomdbDataId);
        AtomDBDataAttribute dataAttribute = attributesRepository.findOne(attributeId);


        if (jobExecution.getStatus() == BatchStatus.FAILED) {

            log.info("ACCOUNT-ID --> {}", accountId);
            log.info("ATOMDB-ID --> {}", atomdbId);
            log.info("ENTRY-ID --> {}", atomdbDataId);
            log.info("ACTION-ID --> {}", atomdbActionId);

            jobExecution.getAllFailureExceptions().stream().forEach(ex -> errorMsgs.add(JobErrorMessageHandler.get(ex.getMessage())));
            String finalMsg = StringUtils.join(errorMsgs, "<br>");

            if (dataAttribute == null) {
                dataAttribute = new AtomDBDataAttribute();
                dataAttribute.setId(attributeId);
                dataAttribute.setValue(finalMsg);
                dataAttribute.setCreated(now);
                dataAttribute.setUpdated(now);
                dataAttribute.setMetadata("String");
            } else {
                dataAttribute.setValue(finalMsg);
                dataAttribute.setUpdated(now);
            }

            attributesRepository.save(dataAttribute);
            log.info("Attribute data {} atualizado com {}", attributeId, finalMsg);

        } else if (jobExecution.getStatus() == BatchStatus.COMPLETED && dataAttribute != null) {
            attributesRepository.delete(attributeId);
            log.info("Attribute data {} removido com sucesso", attributeId);
        }

        if (log.isDebugEnabled()) {
            log.debug("-- Job {} ERROR HANDLER com ID {}: FINALIZADO", jobExecution.getJobInstance().getJobName(), jobExecution.getJobId());
        }
    }
}
