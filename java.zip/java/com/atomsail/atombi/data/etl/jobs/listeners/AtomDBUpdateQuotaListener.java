package com.atomsail.atombi.data.etl.jobs.listeners;

import com.atomsail.atombi.data.etl.domain.*;
import com.atomsail.atombi.data.etl.repositories.AccountQuotaRepository;
import com.atomsail.atombi.data.etl.repositories.AtomDBActionRepository;
import com.atomsail.atombi.data.etl.repositories.AtomDBDataAttributesRepository;
import com.atomsail.atombi.data.etl.repositories.AtomDBDataRepository;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;

public class AtomDBUpdateQuotaListener implements JobExecutionListener {

    private static final Logger log = LoggerFactory.getLogger(AtomDBUpdateQuotaListener.class);


    @Autowired
    private AtomDBDataAttributesRepository attributesRepository;

    @Autowired
    private AccountQuotaRepository quotaRepository;

    @Override
    public void beforeJob(JobExecution jobExecution) {
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void afterJob(JobExecution jobExecution) {



        if (jobExecution.getStatus() == BatchStatus.COMPLETED) {

            Long atomdbDataId = jobExecution.getJobParameters().getLong("atomdbDataId");
            Long accountId = jobExecution.getJobParameters().getLong("accountId");

            AtomDBDataAttributePK attributeSizeId = new AtomDBDataAttributePK();
            attributeSizeId.setAtomdbDataId(atomdbDataId);
            attributeSizeId.setAtomdbDataAttribute(AtomDBDataAttributeType.SIZE);

            AtomDBDataAttribute sizeAttribute = attributesRepository.findOne(attributeSizeId);


            AccountQuotaPK storageQuotaId = new AccountQuotaPK();
            storageQuotaId.setAccountId(accountId);
            storageQuotaId.setQuotaTypeId(QuotaTypeId.STORAGE);

            AccountQuota storageQuota = quotaRepository.getOne(storageQuotaId);

            BigDecimal value = BigDecimal.valueOf(new Double(sizeAttribute.getValue()));
            BigDecimal beforeUpdate = storageQuota.getUsed();
            BigDecimal afterUpdate = storageQuota.getUsed().add(value);

            storageQuota.setUpdated(new Date());
            storageQuota.setUsed(afterUpdate);

            quotaRepository.save(storageQuota);

            log.info("Cota STORAGE atualizada de {} -> {} - Total: {}", beforeUpdate, afterUpdate, storageQuota.getSize());

            if (storageQuota.getSize().compareTo(afterUpdate) < 0) {
                log.info("COTA EXCEDIDA {} -> {} - Total: {}", beforeUpdate, afterUpdate, storageQuota.getSize());
            }

        }

    }
}
