package com.atomsail.atombi.data.etl.jobs.star.csv;

import java.text.MessageFormat;

public class SparkSqlFieldTemplates {

    /**
     * Template de campo texto para consultas sql no spark
     * - Param 0: referencia do campo
     * - Param 1: alias do campo
     */
    public static final String TEXT_FIELD_TEMPLATE_MD5 = "md5(if({0} is null, ''''null'''', trim({0}))) as {1}";
    public static final String TEXT_FIELD_TEMPLATE_MD5_NO_ALIAS = "md5(if({0} is null, ''''null'''', trim({0})))";

    public static final String TEXT_FIELD_TEMPLATE_MD5_NORMALIZED_NO_ALIAS = "md5(atom_text_normalized_ascii(if({0} is null, ''''null'''', trim({0})), ''{1}''))";

    public static final String TEXT_FIELD_TEMPLATE = "trim({0}) as {1}";

    public static final String TEXT_FIELD_NORMALIZED_ASCII_TEMPLATE = "atom_text_normalized_ascii(trim({0}), ''{1}'')";


    /**
     * Template de campo numerico para consultas sql no spark
     * - Param 0: referencia do campo
     * - Param 1: nome do campo de entrada
     * - Param 2: alias do campo
     */
    public static final String NUMBER_FIELD_TEMPLATE = "atom_number({0}, ''{1}'', ''{2}'') as {3}";

    /**
     * Template de time_id para consultas sql no spark
     * - Param 0: referencia do campo data
     * - Param 1: formato de parse
     * - Param 2: nome do campo de entrada
     * - Param 3: alias do campo
     */
    public static final String TIME_ID_FIELD_TEMPLATE = "atom_time_id({0},''{1}'', ''{2}'') as {3}";

    public static String getTextMd5Field(String fieldName, String alias) {

        return getTextMd5Field(fieldName, alias, false);

    }

    public static String getTextMd5Field(String fieldName, String alias, boolean replaceQuote) {

        String textField = MessageFormat.format(SparkSqlFieldTemplates.TEXT_FIELD_TEMPLATE_MD5,
                fieldName,
                alias);

        return replaceQuote ? textField.replaceAll("''", "'") : textField;

    }

    public static String getTextMd5FieldNormalizedAscii(String fieldName, String name, boolean replaceQuote) {
        String textField = MessageFormat.format(SparkSqlFieldTemplates.TEXT_FIELD_TEMPLATE_MD5_NORMALIZED_NO_ALIAS, fieldName, name);
        return replaceQuote ? textField.replaceAll("''", "'") : textField;

    }

    public static String getTextMd5FieldNoAlias(String fieldName, String alias, boolean replaceQuote) {

        String textField = MessageFormat.format(SparkSqlFieldTemplates.TEXT_FIELD_TEMPLATE_MD5_NO_ALIAS,
                fieldName,
                alias);

        return replaceQuote ? textField.replaceAll("''", "'") : textField;

    }

    public static String geTextField(String fieldName,  String alias) {
        return MessageFormat.format(SparkSqlFieldTemplates.TEXT_FIELD_TEMPLATE, fieldName, alias);
    }

    public static String geTextFieldNormalizedAscii(String fieldName, String name, String alias) {
        return geTextFieldNormalizedAscii(fieldName, name) + " as " + alias;
    }

    public static String geTextFieldNormalizedAscii(String fieldName, String name) {
        return MessageFormat.format(SparkSqlFieldTemplates.TEXT_FIELD_NORMALIZED_ASCII_TEMPLATE, fieldName, name);
    }

    public static String getFileDistinctValues(String fieldName, String idAlias, String md5Alias, String table) {

        String sql = "select distinct {2}, trim({0}) as {0} from {1}";

        return sql;

    }

}
