package com.atomsail.atombi.data.etl.jobs.export;

public class AtomDBExportException extends Exception {

    public AtomDBExportException() {
    }

    public AtomDBExportException(String message) {
        super(message);
    }

    public AtomDBExportException(String message, Throwable cause) {
        super(message, cause);
    }
}
