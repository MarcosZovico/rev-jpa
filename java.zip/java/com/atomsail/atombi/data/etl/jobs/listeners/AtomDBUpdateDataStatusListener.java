package com.atomsail.atombi.data.etl.jobs.listeners;

import com.atomsail.atombi.data.etl.domain.AtomDBData;
import com.atomsail.atombi.data.etl.domain.AtomDBDataStatus;
import com.atomsail.atombi.data.etl.repositories.AtomDBActionRepository;
import com.atomsail.atombi.data.etl.repositories.AtomDBDataAttributesRepository;
import com.atomsail.atombi.data.etl.repositories.AtomDBDataRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

public class AtomDBUpdateDataStatusListener implements JobExecutionListener {

    private static final Logger log = LoggerFactory.getLogger(AtomDBUpdateDataStatusListener.class);

    @Autowired
    private AtomDBDataRepository dataRepository;

    @Override
    public void beforeJob(JobExecution jobExecution) {
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void afterJob(JobExecution jobExecution) {

        Date now = new Date();

        Long atomdbDataId = jobExecution.getJobParameters().getLong("atomdbDataId");

        AtomDBData atomDBData = dataRepository.getOne(atomdbDataId);

        atomDBData.setUpdated(now);

        if (jobExecution.getStatus() == BatchStatus.COMPLETED) {

            atomDBData.setStatus(AtomDBDataStatus.COMPLETED);
            dataRepository.save(atomDBData);

        } else if (jobExecution.getStatus() == BatchStatus.FAILED) {

            atomDBData.setStatus(AtomDBDataStatus.ERROR);
            dataRepository.save(atomDBData);
        }

        log.info("Data Entry [{}] atualizada para {}", atomdbDataId, atomDBData.getStatus().name());

    }
}
