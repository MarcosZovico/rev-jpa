package com.atomsail.atombi.data.etl.jobs.flat.csv;

import com.atomsail.atombi.data.etl.domain.AtomDBDataAttribute;
import com.atomsail.atombi.data.etl.domain.AtomDBDataAttributeType;
import com.atomsail.atombi.data.etl.domain.AtomDBField;
import com.atomsail.atombi.data.etl.dto.FieldInputMapDTO;
import com.atomsail.atombi.data.etl.jobs.EtlEngineRunException;
import com.atomsail.atombi.data.etl.jobs.EtlProcess;
import com.atomsail.atombi.data.etl.repositories.AtomDBDataAttributesRepository;
import com.atomsail.atombi.data.etl.repositories.AtomDBFieldRepository;
import com.atomsail.atombi.data.etl.utils.AtomdbDataAttributeUtil;
import com.atomsail.atombi.data.etl.utils.FromToMapUtil;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.*;
import java.util.stream.Collectors;

//@Service
public class SparkEtlProcess implements EtlProcess {

    public static final String MAX_ROWS_PER_FILE = "100000";
    private static final Logger log = LoggerFactory.getLogger(SparkEtlProcess.class);
    @Value("${atombi.data.atomdb.entry.pending_template}")
    private String s3InputTemplate;

    @Value("${atombi.data.atomdb.entry.done_template}")
    private String s3OutputTemplate;

    @Autowired
    private Environment env;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private SparkSession sparkSession;

    @Autowired
    private AtomDBFieldRepository fieldRepository;

    @Autowired
    private AtomDBDataAttributesRepository attributesRepository;

    @Override
    public void execute(Long accountId, Long atomdbId, Long atomdbDataId, Long dbActionId) throws EtlEngineRunException {


        String dataHost = env.getProperty("atombi.data.server.host");
        String dataContext = env.getProperty("atombi.data.server.context");

        try {

            String sparkTempView = "s" + atomdbId + "_entry" + atomdbDataId;


            List<AtomDBField> fields = fieldRepository.findByAtomDB_AtomdbId(atomdbId);
            List<AtomDBDataAttribute> attributes = attributesRepository.findAtomdbDataAttributeById_AtomdbDataId(atomdbDataId);


            Optional<AtomDBDataAttribute> header = AtomdbDataAttributeUtil.get(AtomDBDataAttributeType.HAS_HEADER, attributes);
            Optional<AtomDBDataAttribute> delimiter = AtomdbDataAttributeUtil.get(AtomDBDataAttributeType.DELIMITER, attributes);
            Optional<AtomDBDataAttribute> fromMap = AtomdbDataAttributeUtil.get(AtomDBDataAttributeType.FROM_TO_MAP, attributes);
            Optional<AtomDBDataAttribute> s3InputFile = AtomdbDataAttributeUtil.get(AtomDBDataAttributeType.S3_URL, attributes);
            List<FieldInputMapDTO> mappedFields = objectMapper.readValue(fromMap.get().getValue(), new TypeReference<List<FieldInputMapDTO>>() {
            });


            List<AtomDBField> sortedFields = fields
                    .stream()
                    .filter(atomDBField ->
                            atomDBField.getType().equals("TEXT") ||
                                    atomDBField.getType().equals("NUMBER") ||
                                    atomDBField.getType().equals("DATE")
                    ).sorted(Comparator.comparing(AtomDBField::getOrder)).collect(Collectors.toList());


            StructField[] structFields = new StructField[sortedFields.size()];
            StringBuilder sparkSql = new StringBuilder();

            // inicia construcao da query

            sparkSql.append("select").append("\n ");

            List<String> queryFields = new ArrayList<>();

            // cria struct dos campos
            for (int i = 0; i < sortedFields.size(); i++) {

                if (sortedFields.get(i).getType().equals("TEXT")) {
                    structFields[i] = new StructField(sortedFields.get(i).getFieldName(), DataTypes.StringType, true, Metadata.empty());
                    queryFields.add("trim(" + sortedFields.get(i).getFieldName() + ") as " + sortedFields.get(i).getFieldName());

                } else if (sortedFields.get(i).getType().equals("NUMBER")) {
                    structFields[i] = new StructField(sortedFields.get(i).getFieldName(), DataTypes.DoubleType, true, Metadata.empty());

                    queryFields.add(sortedFields.get(i).getFieldName());

                } else if (sortedFields.get(i).getType().equals("DATE")) {
                    structFields[i] = new StructField(sortedFields.get(i).getFieldName(), DataTypes.StringType, true, Metadata.empty());

                    Optional<FieldInputMapDTO> dateFormat = FromToMapUtil.getFieldByOrder(mappedFields, sortedFields.get(i).getOrder());

                    String format = dateFormat.get().getFormat();
                    String toDate = "to_date(" + sortedFields.get(i).getFieldName() + ", '" + format + "')";

                    queryFields.add(toDate + " as " + sortedFields.get(i).getFieldName() + "_date");
                    queryFields.add("year(" + toDate + ") as " + sortedFields.get(i).getFieldName() + "_year");
                    queryFields.add("halfyear(" + toDate + ") as " + sortedFields.get(i).getFieldName() + "_halfyear");
                    queryFields.add("quarter(" + toDate + ") as " + sortedFields.get(i).getFieldName() + "_quarter");
                    queryFields.add("month(" + toDate + ") as " + sortedFields.get(i).getFieldName() + "_month");
                    queryFields.add("weekofyear(" + toDate + ") as " + sortedFields.get(i).getFieldName() + "_week");
                    queryFields.add("dayofmonth(" + toDate + ") as " + sortedFields.get(i).getFieldName() + "_day");
                }
            }


            String queryBody = String.join(", \n", queryFields);
            sparkSql.append(queryBody).append("\n ").append(" from " + sparkTempView);


            StructType customSchema = new StructType(structFields);

            String inputFile = MessageFormat.format(s3InputTemplate, s3InputFile.get().getValue());
            Dataset<Row> dataSet = sparkSession
                    .read()
                    .format("com.databricks.spark.csv")
                    .option("header", header.get().getValue())
                    .option("codec", "org.apache.hadoop.io.compress.GzipCodec")
                    .option("delimiter", delimiter.get().getValue())
                    .option("mode", "failFast")
                    .option("quote", "\"")
                    .schema(customSchema)
                    .csv(inputFile);

            dataSet.createOrReplaceTempView(sparkTempView);


            String s3TargetPath = MessageFormat.format(s3OutputTemplate, accountId, atomdbId, atomdbDataId);
            dataSet.sqlContext().sql(sparkSql.toString())
                    .write()
                    .mode("overwrite")
                    .format("com.databricks.spark.csv")
                    .option("delimiter", "|")
                    .option("maxRecordsPerFile", MAX_ROWS_PER_FILE)
                    .option("codec", "org.apache.hadoop.io.compress.GzipCodec")
                    .save(s3TargetPath);

            // remove tabela temporaria
            sparkSession.sqlContext().dropTempTable(sparkTempView);


            AtomDBDataAttribute updatedDonePath = AtomdbDataAttributeUtil.get(AtomDBDataAttributeType.S3_DONE_URL, attributes).get();
            updatedDonePath.setValue(s3TargetPath);
            updatedDonePath.setUpdated(new Date());
            attributesRepository.save(updatedDonePath);

            log.info("criacao do csv para carga de dados finalizado para [atomdb: {}], atomdbDataId: {}", atomdbId, atomdbDataId);

            restTemplate.put(dataHost + dataContext + MessageFormat.format(env.getProperty("atombi.data.server.path"), atomdbDataId, "FACT_LOAD", dbActionId), null);

        } catch (JsonParseException e) {
            log.error(e.getMessage(), e);
            restTemplate.put(dataHost + dataContext + MessageFormat.format(env.getProperty("atombi.data.server.path"), atomdbDataId, "FACT_LOAD", dbActionId), null);
            throw new EtlEngineRunException(e);
        } catch (JsonMappingException e) {
            log.error(e.getMessage(), e);
            restTemplate.put(dataHost + dataContext + MessageFormat.format(env.getProperty("atombi.data.server.path"), atomdbDataId, "FACT_LOAD", dbActionId), null);
            throw new EtlEngineRunException(e);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
            restTemplate.put(dataHost + dataContext + MessageFormat.format(env.getProperty("atombi.data.server.path"), atomdbDataId, "FACT_LOAD", dbActionId), null);
            throw new EtlEngineRunException(e);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            restTemplate.put(dataHost + dataContext + MessageFormat.format(env.getProperty("atombi.data.server.path"), atomdbDataId, "FACT_LOAD", dbActionId), null);
            throw new EtlEngineRunException(e);
        }

    }


}
