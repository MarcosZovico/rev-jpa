package com.atomsail.atombi.data.etl.jobs.star.csv.tasks.dummy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;

public class DummyTasklet implements Tasklet, InitializingBean {

    private static final Logger log = LoggerFactory.getLogger(DummyTasklet.class);

    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {

        log.info("Executado {} com nome: {}", DummyTasklet.class.getSimpleName(), chunkContext.getStepContext().getStepName());

        return RepeatStatus.FINISHED;
    }


    @Override
    public void afterPropertiesSet() throws Exception {
    }
}
