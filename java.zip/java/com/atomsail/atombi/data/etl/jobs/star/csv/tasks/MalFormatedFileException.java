package com.atomsail.atombi.data.etl.jobs.star.csv.tasks;

public class MalFormatedFileException extends Exception {
    public MalFormatedFileException() {
    }

    public MalFormatedFileException(String message) {
        super(message);
    }

    public MalFormatedFileException(String message, Throwable cause) {
        super(message, cause);
    }

    public MalFormatedFileException(Throwable cause) {
        super(cause);
    }

    public MalFormatedFileException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
