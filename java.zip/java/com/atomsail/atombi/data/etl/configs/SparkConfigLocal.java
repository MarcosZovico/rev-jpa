package com.atomsail.atombi.data.etl.configs;

import org.apache.spark.SparkConf;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.atomsail.atombi.data.etl.engine.spark.udf.date.AtomTimeId.atom_time_id;
import static com.atomsail.atombi.data.etl.engine.spark.udf.date.HalfYear.halfyear;
import static com.atomsail.atombi.data.etl.engine.spark.udf.number.AtomNumber.atom_number;
import static com.atomsail.atombi.data.etl.engine.spark.udf.text.AtomTextNormalizedASCII.atom_text_normalized_ascii;


@Configuration
@ConditionalOnProperty(name = "spark.master", matchIfMissing = true, havingValue = "no")
public class SparkConfigLocal {

    private static final Logger log = LoggerFactory.getLogger(SparkConfigLocal.class);

    @Autowired
    private SparkConf sparkConf;

    @Bean
    public SparkSession sparkSession() {

        SparkSession sparkSession = SparkSession.builder().master("local[*]").config(sparkConf).getOrCreate();

        sparkSession.udf().register("halfyear", halfyear, DataTypes.IntegerType);
        sparkSession.udf().register("atom_time_id", atom_time_id, DataTypes.StringType);
        sparkSession.udf().register("atom_number", atom_number, DataTypes.DoubleType);
        sparkSession.udf().register("atom_text_normalized_ascii", atom_text_normalized_ascii, DataTypes.StringType);

        log.info("Spark Session Local configurado com sucesso");

        return sparkSession;
    }
}
