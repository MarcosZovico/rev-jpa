package com.atomsail.atombi.data.etl.configs;

import org.apache.spark.SparkConf;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;

@Configuration
public class SparkConfig {

    private static final Logger log = LoggerFactory.getLogger(SparkConfig.class);

    @Value("${spark.appName:atombi-data-etl}")
    private String appName;

    @Value("${spark.warehouse.dir:/tmp}")
    private String warehouseDir;

    @Value("${spark.executor.memory:2g}")
    private String executorMemory;

    @Autowired
    @Qualifier("sparkLibs")
    private String[] sparkLibs;

    @Bean
    public SparkConf sparkConf() throws IOException {

        SparkConf sparkConf = new SparkConf();

        sparkConf.setAppName(appName);

        sparkConf.set("spark.history.fs.cleaner.enabled", "true");
        sparkConf.set("spark.history.fs.cleaner.maxAge", "6h");
        sparkConf.set("spark.history.fs.cleaner.interval", "1h");

        sparkConf.set("fs.s3a.access.key", System.getenv("AWS_ACCESS_KEY_ID"));
        sparkConf.set("fs.s3a.secret.key", System.getenv("AWS_SECRET_ACCESS_KEY"));
        sparkConf.set("fs.s3a.fast.upload", "true");
        sparkConf.set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem");
        sparkConf.set("spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version", "2");
        sparkConf.set("spark.executor.memory", executorMemory);
        sparkConf.set("spark.driver.allowMultipleContexts", "true");
        sparkConf.set("spark.shuffle.service.enabled", "true");
        sparkConf.set("spark.dynamicAllocation.enabled", "true");
        sparkConf.set("spark.sql.warehouse.dir", warehouseDir);
        sparkConf.set("spark.cores.max",  "2");
        sparkConf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer");
        sparkConf.setJars(sparkLibs);

        log.info("Spark Config utilizando S3 com chave: {}", System.getenv("AWS_ACCESS_KEY_ID"));
        log.info("Spark Config configurado com sucesso");

        return sparkConf;
    }
}

