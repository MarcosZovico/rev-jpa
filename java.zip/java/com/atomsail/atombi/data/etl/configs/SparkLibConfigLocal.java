package com.atomsail.atombi.data.etl.configs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import java.io.IOException;

@Configuration
public class SparkLibConfigLocal {

    private static final Logger log = LoggerFactory.getLogger(SparkLibConfigLocal.class);

    private PathMatchingResourcePatternResolver resourceLoader = new PathMatchingResourcePatternResolver();


//    @Bean
//    @Qualifier("sparkLibs")
//    public String[] sparkLibs() throws IOException {
//
//        Resource[] resources = resourceLoader.getResources("spark/*");
//        String[] paths = new String[resources.length];
//
//        for (int i = 0; i < resources.length; i++) {
//            paths[i] = resources[i].getURL().getFile();
//            if (log.isTraceEnabled()) {
//                log.trace("lib encontrada: {}", paths[i]);
//            }
//        }
//
//        log.info("Spark libs identificadas com sucesso da jar /src/spark-libs");
//
//
//        return paths;
//    }

    @Bean
    @Qualifier("sparkLibs")
    public String[] sparkLibs() throws IOException {

        String[] paths = new String[]{
//                "/Users/jarbasmoraes/Documents/dev/maven/repository/com/atomsail/atombi/spark/spark-lib/1.0.0.13-SNAPSHOT/spark-lib-1.0.0.13-SNAPSHOT.jar"
//                ,"/Users/jarbasmoraes/Documents/dev/maven/repository/com/amazonaws/aws-java-sdk-core/1.10.6/aws-java-sdk-core-1.10.6.jar"
//                ,"/Users/jarbasmoraes/Documents/dev/maven/repository/com/amazonaws/aws-java-sdk-kms/1.10.6/aws-java-sdk-kms-1.10.6.jar"
//                ,"/Users/jarbasmoraes/Documents/dev/maven/repository/com/amazonaws/aws-java-sdk-s3/1.10.6/aws-java-sdk-s3-1.10.6.jar"
//                ,"/Users/jarbasmoraes/Documents/dev/maven/repository/org/apache/hadoop/hadoop-aws/2.8.3/hadoop-aws-2.8.3.jar"
//                ,"/Users/jarbasmoraes/Documents/dev/maven/repository/org/apache/hadoop/hadoop-common/2.8.3/hadoop-common-2.8.3.jar"
//                ,"/Users/jarbasmoraes/Documents/dev/maven/repository/com/amazonaws/aws-java-sdk/1.7.4/aws-java-sdk-1.7.4.jar"
//                ,"/Users/jarbasmoraes/Documents/dev/maven/repository/org/apache/hadoop/hadoop-aws/2.7.3/hadoop-aws-2.7.3.jar"
        };

        log.info("Spark libs identificadas com sucesso da jar /src/spark-libs");


        return paths;
    }
}
